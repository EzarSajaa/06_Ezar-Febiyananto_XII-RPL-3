<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'config/database.php';

$auth = new Auth();
if (!$auth->isLoggedIn() || !($auth->isAdmin() || $auth->isSuperAdmin())) {
    redirect('login.php');
}
$currentUser = $auth->getCurrentUser();

$db = new Database();
$conn = $db->getConnection();

// Read filters (POST to avoid exposing in URL)
$reportType = sanitize_input($_POST['type'] ?? 'incoming'); // incoming|outgoing
$date = sanitize_input($_POST['date'] ?? '');
$export = sanitize_input($_POST['export'] ?? '');
$selectedDept = sanitize_input($_POST['department'] ?? '');

// Build query - show all documents by default, but allow date filtering
// Department filter: superadmin dapat memilih (lihat semua jika kosong/all), lainnya dibatasi ke department mereka
if ($auth->isSuperAdmin()) {
    if (empty($selectedDept) || $selectedDept === 'all') {
        $dept = null; // semua
    } else {
        $dept = $selectedDept;
    }
} else {
    $dept = $currentUser['department'] ?? null;
}

// Ambil daftar departemen untuk dropdown (hanya jika superadmin)
$deptList = [];
if ($auth->isSuperAdmin()) {
    $q = $conn->prepare("SELECT DISTINCT TRIM(department) as department FROM users WHERE department IS NOT NULL AND department <> '' ORDER BY department");
    $q->execute();
    $deptRows = $q->fetchAll(PDO::FETCH_ASSOC);
    $deptList = array_column($deptRows, 'department');
    // Remove the legacy/role-like department name 'Admin Utama' from the list
    $deptList = array_values(array_filter($deptList, function($d) {
        return !(strcasecmp(trim($d), 'Admin Utama') === 0);
    }));
}
$params = [];
$whereClause = "";

if ($reportType === 'outgoing') {
    $sql = "
        SELECT dl.id, dl.download_date as activity_date,
               d.title, d.original_filename, u.full_name as user_name,
               u.department as user_department
        FROM download_logs dl
        INNER JOIN documents d ON d.id = dl.document_id
        INNER JOIN users u ON u.id = dl.user_id
        WHERE 1 = 1
    ";
    if (!empty($dept)) {
        $sql .= " AND LOWER(TRIM(d.target_department)) = LOWER(TRIM(?))";
        $params[] = $dept;
    }
    if (!empty($date)) {
        $whereClause = " AND DATE(dl.download_date) = ?";
        $params[] = $date;
    }
    $sql .= $whereClause . " ORDER BY dl.download_date DESC";
    $title = 'Laporan Dokumen Keluar (Download)';
} else {
    $sql = "
        SELECT d.id, d.upload_date as activity_date,
               d.title, d.original_filename, u.full_name as user_name,
               u.department as user_department
        FROM documents d
        INNER JOIN users u ON u.id = d.uploaded_by
        WHERE d.status = 'active'
    ";
    if (!empty($dept)) {
        $sql .= " AND LOWER(TRIM(d.target_department)) = LOWER(TRIM(?))";
        $params[] = $dept;
    }
    if (!empty($date)) {
        $whereClause = " AND DATE(d.upload_date) = ?";
        $params[] = $date;
    }
    $sql .= $whereClause . " ORDER BY d.upload_date DESC";
    $title = 'Laporan Dokumen Masuk (Upload)';
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

// Export PDF if requested
if ($export === 'pdf') {
    // Redirect to PDF report page
    $exportParams = [
        'type' => $reportType,
        'date' => $date
    ];
    // Only include department parameter for superadmin (others will be ignored server-side)
    if ($auth->isSuperAdmin()) {
        $exportParams['department'] = empty($selectedDept) ? 'all' : $selectedDept;
    }
    $params = http_build_query($exportParams);
    header('Location: pdf_report.php?' . $params);
    exit;
}

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content { margin-left: var(--sidebar-width); min-height: 100vh; background: #f8f9fa; }
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 767.98px) {
            .sidebar { position: static; width: 100%; height: auto; overflow: visible; background: linear-gradient(135deg, #495057 0%, #6c757d 100%); color: white; }
            .main-content { margin-left: 0; background: #f8f9fa; }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
    </style>
    </head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="user-info text-center mb-3">
                        <i class="fas fa-user-circle fa-3x mb-2"></i>
                        <h6><?php echo htmlspecialchars($currentUser['full_name']); ?></h6>
                        <small class="text-white-50">
                            <i class="fas fa-building me-1"></i>
                            <?php echo htmlspecialchars($currentUser['department']); ?>
                        </small>
                    </div>
                    <nav class="nav flex-column">
                        <a class="nav-link" href="index.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                        <a class="nav-link" href="documents.php"><i class="fas fa-file-alt me-2"></i>Dokumen</a>
                        <a class="nav-link" href="search.php"><i class="fas fa-search me-2"></i>Pencarian</a>
                        <a class="nav-link" href="categories.php"><i class="fas fa-tags me-2"></i>Kategori</a>
                        <a class="nav-link" href="users.php"><i class="fas fa-users me-2"></i>Users</a>
                        <a class="nav-link active" href="reports.php"><i class="fas fa-chart-line me-2"></i>Laporan</a>
                        <a class="nav-link" href="backup.php"><i class="fas fa-database me-2"></i>Backup</a>
                        <a class="nav-link" href="profile.php"><i class="fas fa-user-cog me-2"></i>Profile</a>
                        <a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
                    </nav>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <span class="navbar-brand">
                                <i class="fas fa-chart-line me-2"></i>
                                Laporan Dokumen
                            </span>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo date('d/m/Y H:i'); ?>
                                </span>
                            </div>
                        </div>
                    </nav>

                    <!-- Content -->
                    <div class="p-4">
                        <!-- Filters -->
                        <div class="card mb-4">
                            <div class="card-body">
                                <form method="POST" action="" class="row g-3 align-items-end">
                                    <div class="col-md-3">
                                        <label class="form-label"><i class="fas fa-list me-2"></i>Tipe Laporan</label>
                                        <select name="type" class="form-select">
                                            <option value="incoming" <?php echo $reportType==='incoming'?'selected':''; ?>>Masuk (Upload)</option>
                                            <option value="outgoing" <?php echo $reportType==='outgoing'?'selected':''; ?>>Keluar (Download)</option>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label"><i class="fas fa-calendar me-2"></i>Tanggal (Opsional)</label>
                                        <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($date); ?>">
                                    </div>
                                    <?php if ($auth->isSuperAdmin()): ?>
                                        <div class="col-md-3">
                                            <label class="form-label"><i class="fas fa-building me-2"></i>Departemen</label>
                                            <select name="department" class="form-select">
                                                <option value="all" <?php echo (empty($selectedDept) || $selectedDept === 'all') ? 'selected' : ''; ?>>Semua Departemen</option>
                                                <?php foreach ($deptList as $d): ?>
                                                    <option value="<?php echo htmlspecialchars($d); ?>" <?php echo (!empty($selectedDept) && strcasecmp(trim($selectedDept), trim($d))===0) ? 'selected' : ''; ?>><?php echo htmlspecialchars($d); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    <?php endif; ?>
                                    <div class="col-md-3 d-flex gap-2">
                                        <button type="submit" class="btn btn-primary flex-fill"><i class="fas fa-search me-2"></i>Terapkan</button>
                                        <button type="submit" name="export" value="pdf" class="btn btn-danger flex-fill"><i class="fas fa-file-pdf me-2"></i>Export PDF</button>
                                    </div>
                                </form>
                                <div class="mt-3">
                                    <small class="text-muted">
                                        <i class="fas fa-info-circle me-1"></i>
                                        <?php if (empty($date)): ?>
                                            Menampilkan semua dokumen. Isi tanggal untuk filter berdasarkan tanggal tertentu.
                                        <?php else: ?>
                                            Menampilkan dokumen untuk tanggal: <strong><?php echo date('d/m/Y', strtotime($date)); ?></strong>
                                        <?php endif; ?>
                                    </small>
                                </div>
                            </div>
                        </div>

                        <!-- Results -->
                        <div class="card">
                            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                <h6 class="mb-0"><?php echo $title; ?></h6>
                                <span class="badge bg-primary"><?php echo count($rows); ?> data</span>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle mb-0">
                                        <thead>
                                            <tr>
                                                <th style="width: 180px;">Tanggal/Waktu</th>
                                                <th>Judul</th>
                                                <th>Nama File</th>
                                                <th>User</th>
                                                <th>Department</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($rows)): ?>
                                                <tr>
                                                    <td colspan="5" class="text-center text-muted py-4">
                                                        <i class="fas fa-info-circle me-2"></i>
                                                        <?php if (empty($date)): ?>
                                                            Tidak ada data <?php echo $reportType === 'outgoing' ? 'download' : 'upload'; ?> yang tersedia
                                                        <?php else: ?>
                                                            Tidak ada data <?php echo $reportType === 'outgoing' ? 'download' : 'upload'; ?> untuk tanggal <?php echo date('d/m/Y', strtotime($date)); ?>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($rows as $r): ?>
                                                    <tr>
                                                        <td><?php echo date('d/m/Y H:i', strtotime($r['activity_date'])); ?></td>
                                                        <td><?php echo htmlspecialchars($r['title']); ?></td>
                                                        <td><?php echo htmlspecialchars($r['original_filename']); ?></td>
                                                        <td><?php echo htmlspecialchars($r['user_name']); ?></td>
                                                        <td><?php echo htmlspecialchars($r['user_department']); ?></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


