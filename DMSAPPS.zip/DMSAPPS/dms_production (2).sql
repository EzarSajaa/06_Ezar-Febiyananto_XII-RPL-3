-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 09, 2025 at 11:58 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dms_production`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text,
  `color` varchar(7) DEFAULT '#007bff',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `color`, `created_at`, `updated_at`) VALUES
(9, 'DEKIDAKA DCM', 'FORM LAPORAN BARANG PRODUKSI', '#FF6B6B', '2025-10-14 05:48:13', '2025-10-14 05:48:13'),
(10, 'INGOT CHARGING', 'FORM KETERCAPAIAN PRODUKSI OLEH OPERATOR ANTARA SHIFT SIANG DAN SHIFT MALAM', '#FFA07A', '2025-10-14 05:49:05', '2025-10-14 05:49:05'),
(11, 'DEBURING', '', '#45B7D1', '2025-10-14 05:49:46', '2025-10-14 05:49:46'),
(12, 'SHOTBLASTING', '', '#4ECDC4', '2025-10-14 05:50:11', '2025-10-14 05:50:11'),
(13, 'T5', '', '#BB8FCE', '2025-10-14 05:50:23', '2025-10-14 05:50:23'),
(14, 'ACCOUNTING', 'DOKUMEN PENCATATAN KEUANGAN', '#F7DC6F', '2025-11-23 08:17:38', '2025-11-23 08:17:38'),
(15, 'IT', 'DOKUMEN IT', '#85C1E2', '2025-11-23 09:28:07', '2025-11-23 09:28:07');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text,
  `filename` varchar(255) NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `category_id` int DEFAULT NULL,
  `production_date` date DEFAULT NULL,
  `upload_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `uploaded_by` int NOT NULL,
  `target_department` varchar(100) DEFAULT NULL COMMENT 'Department tujuan dokumen',
  `status` enum('active','archived','deleted') DEFAULT 'active',
  `tags` text,
  `shift` varchar(10) DEFAULT NULL,
  `page_count` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `documents`
--

INSERT INTO `documents` (`id`, `title`, `description`, `filename`, `original_filename`, `file_path`, `file_size`, `file_type`, `category_id`, `production_date`, `upload_date`, `uploaded_by`, `target_department`, `status`, `tags`, `shift`, `page_count`) VALUES
(1, 'Laporan masalah frontend', 'LAPORAN', '68edeae447535_1760422628.jpg', 'tacilogo.jpg', 'uploads/68edeae447535_1760422628.jpg', 9414, 'jpg', 15, '2025-10-14', '2025-10-14 06:17:08', 5, 'IT', 'active', '', 'pagi', 5),
(2, 'PERTAMA', 'DATA PERTAMA', '68edee7282771_1760423538.jpg', 'WhatsApp Image 2025-09-01 at 17.51.03_26879b5d.jpg', 'uploads/68edee7282771_1760423538.jpg', 189048, 'jpg', 15, '2025-10-14', '2025-10-14 06:32:18', 5, 'IT', 'active', '', 'pagi', 1),
(3, 'DATA IT KETIGA', 'DATA KETIGA', '68edf2cb8837b_1760424651.pdf', 'APLIKASI STOPWATCH.pdf', 'uploads/68edf2cb8837b_1760424651.pdf', 485858, 'pdf', 15, '2025-10-14', '2025-10-14 06:50:51', 5, 'IT', 'active', '', 'malam', 15),
(4, 'DATA IT KEDUA', 'DATA KEDUA', '68edf2d1dd18d_1760424657.pdf', 'APLIKASI STOPWATCH.pdf', 'uploads/68edf2d1dd18d_1760424657.pdf', 485858, 'pdf', 15, '2025-10-14', '2025-10-14 06:50:57', 5, 'IT', 'active', '', 'malam', 15),
(5, 'DATA IT PERTAMA', 'KUMPULAN DATA', '68edf4e03195a_1760425184.pdf', '100-radicals .pdf', 'uploads/68edf4e03195a_1760425184.pdf', 228855, 'pdf', 15, '2025-10-14', '2025-10-14 06:59:44', 5, 'IT', 'active', '', 'pagi', 2),
(6, 'LOGO TACI', 'PT TD AUTOMOTIVE COMPRESSOR INDONESIA', '68edfbc0efba5_1760426944.jpg', 'tacilogo (1).jpg', 'uploads/68edfbc0efba5_1760426944.jpg', 9414, 'jpg', 9, '2025-10-14', '2025-10-14 07:29:04', 5, 'IT', 'active', '', 'pagi', 1),
(7, 'ACTIVITY DIAGRAM', 'ACTIVITY DIAGRAM DOCUFLOW', '68fb7f1be6fd5_1761312539.png', 'Activity Diagram  Docuflow.drawio (1).png', 'uploads/68fb7f1be6fd5_1761312539.png', 85372, 'png', 12, '2025-10-24', '2025-10-24 13:28:59', 5, 'IT', 'active', '', 'pagi', 1),
(8, 'ENTITIY RELATIONSHIP DIAGRAM', 'ERD APLIKASI DOCUFLOE', '68fb86273e1ac_1761314343.png', 'ERD DOCUFLOW.drawio (1).png', 'uploads/68fb86273e1ac_1761314343.png', 237673, 'png', 10, '2025-10-24', '2025-10-24 13:59:03', 5, 'IT', 'active', '', 'pagi', 1),
(9, 'TEST', 'FILE TEST', '68fc2b4a3877c_1761356618.png', 'Asus TUF F15.png', 'uploads/68fc2b4a3877c_1761356618.png', 400797, 'png', 9, '2025-10-25', '2025-10-25 01:43:38', 5, 'IT', 'active', '', 'pagi', 1),
(10, 'TEST PRODUKSI', 'FILE TEST', '68fc2baed98a2_1761356718.docx', 'LEMBAR OBSERVASI PKL EZAR - ke 1.docx', 'uploads/68fc2baed98a2_1761356718.docx', 38437, 'docx', 11, '2025-10-25', '2025-10-25 01:45:18', 6, 'PRODUKSI', 'active', '', 'pagi', 1),
(11, 'DATA PRODUKSI BULAN SEPTEMBER', 'DOKUMEN DOKUMEN CATATAN', '68fcc81295767_1761396754.jpg', 'WhatsApp Image 2025-09-06 at 08.26.22_fb180cf5.jpg', 'uploads/68fcc81295767_1761396754.jpg', 78658, 'jpg', 13, '2025-10-25', '2025-10-25 12:52:34', 6, 'PRODUKSI', 'active', '', 'malam', 1),
(12, 'DATA LAPORAN', 'LAPORAN MALFUNGSI', '6901d6275a6a7_1761728039.pdf', 'Reports - Room Booking System.pdf', 'uploads/6901d6275a6a7_1761728039.pdf', 104401, 'pdf', 15, '2025-10-29', '2025-10-29 08:53:59', 5, 'IT', 'active', '', 'malam', 2),
(13, 'DATA PENGAJUAN PEMBUATAN APPS', 'LAMPIRAN PEMBUATAN APPS', '6901d6a0858c0_1761728160.pdf', 'form_pengajuan_judul[1].pdf', 'uploads/6901d6a0858c0_1761728160.pdf', 84078, 'pdf', 15, '2025-10-29', '2025-10-29 08:56:00', 5, 'IT', 'active', '', 'pagi', 2),
(14, 'DATA ANIMASI', 'DATA PROGRES PEMBUATAN ANIMASI', '6901e02fcf79c_1761730607.pdf', 'Animasi Teks.pdf', 'uploads/6901e02fcf79c_1761730607.pdf', 413116, 'pdf', 15, '2025-10-29', '2025-10-29 09:36:47', 5, 'IT', 'active', '', 'pagi', 4),
(15, 'PENGISIAN FORM PENGADUAN', 'DATA DATA PENGADUAN LAYANAN', '690d641de09c6_1762485277.pdf', 'PENULISAN JURNAL FERNANDA.pdf', 'uploads/690d641de09c6_1762485277.pdf', 6322253, 'pdf', 15, '2025-11-07', '2025-11-07 03:14:37', 5, 'IT', 'active', '', 'pagi', 71),
(16, 'DATA IT EXCEL', 'DATA AKSES DOKUMEN', '690d6740ce2bc_1762486080.xlsx', 'design_project_system_kasir_kirim_aa.xlsx', 'uploads/690d6740ce2bc_1762486080.xlsx', 15475, 'xlsx', 15, '2025-11-07', '2025-11-07 03:28:00', 5, 'IT', 'active', '', 'pagi', 1),
(17, 'Data Gaji Karyawan', 'Data Perhitungan Gaji Karyawan', '69269becbb8d1_1764137964.pdf', 'BAB I Jurnal.pdf', 'uploads/69269becbb8d1_1764137964.pdf', 177313, 'pdf', 14, '2025-11-26', '2025-11-26 06:19:24', 10, 'ACCOUNTING', 'active', '', 'pagi', 2),
(18, 'contoh', 'contoh', '692a190a59f55_1764366602.xlsx', 'design_project_system_kasir_kirim_aa.xlsx', 'uploads/692a190a59f55_1764366602.xlsx', 15475, 'xlsx', 15, '2025-11-29', '2025-11-28 21:50:02', 5, 'IT', 'active', '', 'pagi', 2),
(19, 'contoh 2', 'contoh 2', '692a1b4910763_1764367177.xlsx', 'design_project_system_kasir_kirim_aa.xlsx', 'uploads/692a1b4910763_1764367177.xlsx', 15475, 'xlsx', 15, '2025-11-29', '2025-11-28 21:59:37', 5, 'IT', 'active', '', 'malam', 1),
(20, 'DATA IT 2', 'CONTOH IT', '692a7bbf15978_1764391871.pdf', 'CONTOH DOCUMENT ACCOUNTING 6 HALAMAN.pdf', 'uploads/692a7bbf15978_1764391871.pdf', 146587, 'pdf', 15, '2025-11-29', '2025-11-29 04:51:11', 5, 'IT', 'active', '', 'pagi', 6);

-- --------------------------------------------------------

--
-- Table structure for table `document_tags`
--

CREATE TABLE `document_tags` (
  `id` int NOT NULL,
  `document_id` int NOT NULL,
  `tag_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `download_logs`
--

CREATE TABLE `download_logs` (
  `id` int NOT NULL,
  `document_id` int NOT NULL,
  `user_id` int NOT NULL,
  `download_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `download_logs`
--

INSERT INTO `download_logs` (`id`, `document_id`, `user_id`, `download_date`, `ip_address`, `user_agent`) VALUES
(1, 1, 3, '2025-10-14 07:00:49', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0'),
(2, 6, 3, '2025-10-14 07:32:35', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0'),
(3, 4, 3, '2025-10-14 08:23:09', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0'),
(4, 8, 3, '2025-10-24 17:15:18', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('user','admin','superadmin') NOT NULL DEFAULT 'user',
  `department` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `role`, `department`, `created_at`, `updated_at`, `is_active`) VALUES
(3, 'admin', '$2y$10$wUkfscYiumEQmkQW.7lE/OfAqDjh16QBBduv0F1PG78fz/bKDxE7.', 'Admin IT', 'admin@company.com', 'admin', 'IT', '2025-08-13 12:46:22', '2025-11-28 01:22:28', 1),
(5, 'Rehan', '$2y$10$kHydMk7gzSDGnfz/OxLWGOR6QTtWMDeij7gM8kW5JYxSdEEntI0BO', 'Rehan kusuma putra', 'rehan122@gmail.com', 'user', 'IT', '2025-09-25 12:33:15', '2025-11-23 08:21:13', 1),
(6, 'EZAR', '$2y$10$SsFONJqM99Ig2cVw5rH2LuzkX4lDMzK3TXDtuFo/To9I4HTqefymC', 'EZAR FEBIYANANTO', 'ezr123@gmail.com', 'user', 'PRODUKSI', '2025-10-14 05:59:25', '2025-11-23 08:21:25', 1),
(7, 'FERNANDA', '$2y$10$uFQcEqqHCkw..ln.u9DSbupsLAwp5EY2N7pekkByEU.GTSaCzF77C', 'FERNANDA DERMAWAN', 'Ferr22@gmail.com', 'admin', 'PRODUKSI', '2025-10-25 01:42:30', '2025-11-23 08:19:03', 1),
(8, 'Marissa', '$2y$10$nejhEJKtvuWcnaQ4hV27L./Lpr20vL6ETZoT.EaeXomwYY5fHT9l.', 'Marissa Dewi Sartika', 'Marissa11@gmail.com', 'superadmin', 'Admin Utama', '2025-10-30 00:17:26', '2025-11-26 06:13:13', 1),
(9, 'Dustin', '$2y$10$uGcfuB5.Ofn5DL3940hbnOXyIZJzJjfajtmnZFaoQHaN1btez7Fhm', 'Agha Dustin', 'Dus@gmail.com', 'user', 'IT', '2025-11-07 03:16:25', '2025-11-07 03:16:25', 1),
(10, 'NAUFAL', '$2y$10$O1ONRqJ9.tqtAqEccPgule8drOg26J6o4fch8lkBo5cFfPnXcxBvu', 'Naufal Maruf Ansori', 'naufal11@gmail.com', 'user', 'ACCOUNTING', '2025-11-26 06:15:46', '2025-11-26 06:15:46', 1),
(11, 'DIMAS', '$2y$10$dwtRktSiivHAN7Sgwo4T/ufPklKTx3pBHy2xBgsMzqMVyw/HbDn0m', 'Dimas Nurdiansyah', 'Dimasz22@gmail.com', 'admin', 'ACCOUNTING', '2025-11-26 06:16:32', '2025-11-26 06:16:32', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uploaded_by` (`uploaded_by`),
  ADD KEY `idx_documents_production_date` (`production_date`),
  ADD KEY `idx_documents_category_id` (`category_id`),
  ADD KEY `idx_documents_upload_date` (`upload_date`),
  ADD KEY `idx_documents_status` (`status`),
  ADD KEY `idx_documents_shift` (`shift`),
  ADD KEY `idx_documents_page_count` (`page_count`),
  ADD KEY `idx_target_department` (`target_department`);

--
-- Indexes for table `document_tags`
--
ALTER TABLE `document_tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_tag` (`document_id`,`tag_name`);

--
-- Indexes for table `download_logs`
--
ALTER TABLE `download_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_document_id` (`document_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_download_date` (`download_date`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `document_tags`
--
ALTER TABLE `document_tags`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `download_logs`
--
ALTER TABLE `download_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `documents`
--
ALTER TABLE `documents`
  ADD CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `document_tags`
--
ALTER TABLE `document_tags`
  ADD CONSTRAINT `document_tags_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `download_logs`
--
ALTER TABLE `download_logs`
  ADD CONSTRAINT `download_logs_ibfk_1` FOREIGN KEY (`document_id`) REFERENCES `documents` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `download_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
