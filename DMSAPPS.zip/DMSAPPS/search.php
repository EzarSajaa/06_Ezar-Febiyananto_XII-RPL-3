<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/Document.php';
require_once 'classes/Category.php';

// Check login
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

$currentUser = $auth->getCurrentUser();
$document = new Document();
$category = new Category();

// Get search parameters via POST to avoid exposing in URL
$keyword = sanitize_input($_POST['keyword'] ?? '');
$categoryId = (int)($_POST['category_id'] ?? 0);
$shift = sanitize_input($_POST['shift'] ?? '');
$pageCount = sanitize_input($_POST['page_count'] ?? '');
$singleDate = sanitize_input($_POST['date'] ?? '');
$page = max(1, (int)($_POST['page'] ?? 1));

// Get categories for filter
$categories = $category->getCategoriesForDropdown();

// Perform search
// Semua user hanya bisa melihat dokumen departemen mereka sendiri
// kecuali superadmin yang bisa melihat semua departemen
$department = $auth->isSuperAdmin() ? null : ($currentUser['department'] ?? null);

$searchResults = $document->searchDocuments(
    $keyword,
    $categoryId,
    $shift,
    $pageCount,
    $singleDate,
    $singleDate,
    $department,
    $page
);

$documents = $searchResults['documents'];
$pagination = $searchResults['pagination'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencarian Dokumen - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                min-height: 100vh;
                background: #f8f9fa;
            }
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 767.98px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                overflow: visible;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: 0;
                background: #f8f9fa;
            }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
        }
        .document-card {
            border-left: 4px solid #495057;
            transition: all 0.3s ease;
        }
        .document-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .category-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
        .search-form {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        .pagination .page-link {
            border-radius: 10px;
            margin: 0 2px;
            border: none;
            color: #667eea;
        }
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: #667eea;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="text-center mb-4">
                        <i class="fas fa-file-alt fa-2x mb-2"></i>
                        <h6><?php echo APP_NAME; ?></h6>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="documents.php">
                            <i class="fas fa-file-alt me-2"></i>Dokumen
                        </a>
                        <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="upload.php">
                                <i class="fas fa-upload me-2"></i>Upload
                            </a>
                        <?php endif; ?>
                        <a class="nav-link active" href="search.php">
                            <i class="fas fa-search me-2"></i>Pencarian
                        </a>
                        <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags me-2"></i>Kategori
                            </a>
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-line me-2"></i>Laporan
                            </a>
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-cog me-2"></i>Profile
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <span class="navbar-brand">
                                <i class="fas fa-search me-2"></i>Pencarian Dokumen
                            </span>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-user me-1"></i>
                                    <?php echo htmlspecialchars($currentUser['full_name']); ?>
                                </span>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- Content -->
                    <div class="p-4">
                        <!-- Search Form -->
                        <div class="search-form">
                            <h5 class="mb-3">
                                <i class="fas fa-search me-2"></i>Filter Pencarian
                            </h5>
                            <form method="POST" action="" id="searchForm">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="keyword" class="form-label">
                                            <i class="fas fa-keyboard me-2"></i>Kata Kunci
                                        </label>
                                        <input type="text" class="form-control" id="keyword" name="keyword" 
                                               value="<?php echo htmlspecialchars($keyword); ?>" 
                                               placeholder="Judul, deskripsi, atau konten dokumen">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="category_id" class="form-label">
                                            <i class="fas fa-tags me-2"></i>Kategori
                                        </label>
                                        <select class="form-select" id="category_id" name="category_id">
                                            <option value="">Semua Kategori</option>
                                            <?php foreach ($categories as $cat): ?>
                                                <option value="<?php echo $cat['id']; ?>" 
                                                        <?php echo $categoryId == $cat['id'] ? 'selected' : ''; ?>>
                                                    <?php echo htmlspecialchars($cat['name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="shift" class="form-label">
                                            <i class="fas fa-clock me-2"></i>Shift
                                        </label>
                                        <select class="form-select" id="shift" name="shift">
                                            <option value="">Semua Shift</option>
                                            <option value="pagi" <?php echo $shift == 'pagi' ? 'selected' : ''; ?>>Shift Pagi</option>
                                            <option value="malam" <?php echo $shift == 'malam' ? 'selected' : ''; ?>>Shift Malam</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="page_count" class="form-label">
                                            <i class="fas fa-file-pdf me-2"></i>Jumlah Halaman PDF
                                        </label>
                                        <input type="number" class="form-control" id="page_count" name="page_count" 
                                               value="<?php echo htmlspecialchars($pageCount); ?>" 
                                               placeholder="Jumlah halaman" min="1">
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="date" class="form-label">
                                            <i class="fas fa-calendar me-2"></i>Tanggal
                                        </label>
                                        <input type="date" class="form-control" id="date" name="date" 
                                               value="<?php echo htmlspecialchars($singleDate); ?>">
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center">
                                    <input type="hidden" name="page" id="page" value="<?php echo (int)$page; ?>">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-search me-2"></i>Cari Dokumen
                                    </button>
                                    <a href="search.php" class="btn btn-outline-secondary">
                                        <i class="fas fa-undo me-2"></i>Reset Filter
                                    </a>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Search Results -->
                        <div class="card">
                            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="fas fa-list me-2"></i>Hasil Pencarian
                                </h5>
                                <span class="badge bg-primary">
                                    <?php echo number_format($pagination['total_records']); ?> dokumen ditemukan
                                </span>
                            </div>
                            <div class="card-body">
                                <?php if (empty($documents)): ?>
                                    <div class="text-center text-muted py-5">
                                        <i class="fas fa-search fa-3x mb-3"></i>
                                        <h5>Tidak ada dokumen yang ditemukan</h5>
                                            <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                                            <p>Coba ubah filter pencarian.</p>
                                        <?php else: ?>
                                            <p>Coba ubah filter pencarian atau upload dokumen baru</p>
                                            <a href="upload.php" class="btn btn-primary">
                                                <i class="fas fa-upload me-2"></i>Upload Dokumen
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <!-- Documents List -->
                                    <?php foreach ($documents as $doc): ?>
                                        <div class="document-card card mb-3">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <h6 class="card-title">
                                                            <i class="fas fa-file-alt me-2 text-primary"></i>
                                                            <?php echo htmlspecialchars($doc['title']); ?>
                                                        </h6>
                                                        <p class="card-text text-muted mb-2">
                                                            <?php echo htmlspecialchars($doc['description']); ?>
                                                        </p>
                                                        <div class="d-flex flex-wrap gap-2 mb-2">
                                                            <span class="badge category-badge" 
                                                                  style="background-color: <?php echo $doc['category_color']; ?>; color: white;">
                                                                <?php echo htmlspecialchars($doc['category_name']); ?>
                                                            </span>
                                                            <?php if ($doc['shift']): ?>
                                                                <span class="badge bg-info">
                                                                    <i class="fas fa-clock me-1"></i>
                                                                    Shift <?php echo ucfirst(htmlspecialchars($doc['shift'])); ?>
                                                                </span>
                                                            <?php endif; ?>
                                                            <?php if ($doc['page_count']): ?>
                                                                <span class="badge bg-secondary">
                                                                    <i class="fas fa-file-pdf me-1"></i>
                                                                    <?php echo htmlspecialchars($doc['page_count']); ?> halaman
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                        <!-- Tags dihapus dari tampilan pencarian -->
                                                    </div>
                                                    <div class="col-md-4 text-end">
                                                        <div class="mb-2">
                                                            <small class="text-muted d-block">
                                                                <i class="fas fa-calendar me-1"></i>
                                                                <?php echo date('d/m/Y', strtotime($doc['upload_date'])); ?>
                                                            </small>
                                                            <small class="text-muted">
                                                                <i class="fas fa-user me-1"></i>
                                                                <?php echo htmlspecialchars($doc['uploader_name']); ?>
                                                            </small>
                                                        </div>
                                                        <div class="d-flex gap-1 justify-content-end">
                                                            <a href="view_document.php?id=<?php echo $doc['id']; ?>" 
                                                               class="btn btn-sm btn-outline-primary">
                                                                <i class="fas fa-eye"></i>
                                                            </a>
                                                            <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                                                                <a href="download.php?id=<?php echo $doc['id']; ?>" 
                                                                   class="btn btn-sm btn-outline-success">
                                                                    <i class="fas fa-download"></i>
                                                                </a>
                                                            <?php endif; ?>
                                                            <?php if ($auth->isAdmin() || $auth->isSuperAdmin() || $doc['uploaded_by'] == $currentUser['id']): ?>
                                                                <a href="edit_document.php?id=<?php echo $doc['id']; ?>" 
                                                                   class="btn btn-sm btn-outline-warning">
                                                                    <i class="fas fa-edit"></i>
                                                                </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                    
                                    <!-- Pagination -->
                                    <?php if ($pagination['total_pages'] > 1): ?>
                                        <nav aria-label="Page navigation" class="mt-4">
                                            <ul class="pagination justify-content-center">
                                                <?php if ($pagination['current_page'] > 1): ?>
                                                    <li class="page-item">
                                                        <button type="button" class="page-link" onclick="gotoPage(<?php echo $pagination['current_page'] - 1; ?>)">
                                                            <i class="fas fa-chevron-left"></i>
                                                        </button>
                                                    </li>
                                                <?php endif; ?>
                                                
                                                <?php
                                                $startPage = max(1, $pagination['current_page'] - 2);
                                                $endPage = min($pagination['total_pages'], $pagination['current_page'] + 2);
                                                
                                                for ($i = $startPage; $i <= $endPage; $i++):
                                                ?>
                                                    <li class="page-item <?php echo $i == $pagination['current_page'] ? 'active' : ''; ?>">
                                                        <button type="button" class="page-link" onclick="gotoPage(<?php echo $i; ?>)">
                                                            <?php echo $i; ?>
                                                        </button>
                                                    </li>
                                                <?php endfor; ?>
                                                
                                                <?php if ($pagination['current_page'] < $pagination['total_pages']): ?>
                                                    <li class="page-item">
                                                        <button type="button" class="page-link" onclick="gotoPage(<?php echo $pagination['current_page'] + 1; ?>)">
                                                            <i class="fas fa-chevron-right"></i>
                                                        </button>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </nav>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function gotoPage(p) {
            var pageInput = document.getElementById('page');
            pageInput.value = p;
            document.getElementById('searchForm').submit();
        }
        // Auto-submit form when category changes
        document.getElementById('category_id').addEventListener('change', function() {
            document.getElementById('searchForm').submit();
        });
    </script>
</body>
</html>
