<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/User.php';

// Check login
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

$currentUser = $auth->getCurrentUser();
$user = new User();

// Get full user data from database (including created_at)
$fullUserData = $user->getFullUserData($currentUser['id']);
if ($fullUserData) {
    $currentUser = array_merge($currentUser, $fullUserData);
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'update_profile') {
        $result = $user->updateOwnProfile($currentUser['id'], $_POST);
        echo json_encode($result);
        exit;
    }
    
    if ($_POST['action'] === 'update_password') {
        $result = $user->updateOwnPassword(
            $currentUser['id'],
            $_POST['current_password'],
            $_POST['new_password']
        );
        echo json_encode($result);
        exit;
    }
}

// Get user statistics
$userStats = $user->getUserStats($currentUser['id']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                min-height: 100vh;
                background: #f8f9fa;
            }
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 767.98px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                overflow: visible;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: 0;
                background: #f8f9fa;
            }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }
        .user-info {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 3rem;
            color: white;
            margin: 0 auto;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        .stat-card {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            color: white;
            border-radius: 15px;
            padding: 1.5rem;
            text-align: center;
            transition: all 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        .stat-icon {
            font-size: 2rem;
            opacity: 0.8;
            margin-bottom: 0.5rem;
        }
        .document-item {
            border-left: 4px solid #495057;
            padding: 0.75rem;
            margin-bottom: 0.5rem;
            background: white;
            border-radius: 0 10px 10px 0;
            transition: all 0.3s ease;
        }
        .document-item:hover {
            transform: translateX(5px);
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        .info-row {
            padding: 1rem;
            border-bottom: 1px solid #e9ecef;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: 600;
            color: #6c757d;
        }
        .password-strength {
            height: 5px;
            border-radius: 3px;
            transition: all 0.3s ease;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="user-info text-center">
                        <i class="fas fa-user-circle fa-3x mb-2"></i>
                        <h6><?php echo htmlspecialchars($currentUser['full_name']); ?></h6>
                        <small class="text-white-50">
                            <i class="fas fa-building me-1"></i>
                            <?php echo htmlspecialchars($currentUser['department']); ?>
                        </small>
                        <div class="mt-2">
                            <span class="badge bg-light text-dark">
                                <i class="fas fa-user-shield me-1"></i>
                                <?php echo ucfirst($currentUser['role']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="documents.php">
                            <i class="fas fa-file-alt me-2"></i>Dokumen
                        </a>
                        <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="upload.php">
                                <i class="fas fa-upload me-2"></i>Upload
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search me-2"></i>Pencarian
                        </a>
                        <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags me-2"></i>Kategori
                            </a>
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-line me-2"></i>Laporan
                            </a>
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        <?php endif; ?>
                        <a class="nav-link active" href="profile.php">
                            <i class="fas fa-user-cog me-2"></i>Profile
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <span class="navbar-brand">
                                <i class="fas fa-user-cog me-2"></i>
                                Profil Saya
                            </span>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo date('d/m/Y H:i'); ?>
                                </span>
                                <div class="dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                        <i class="fas fa-user-circle me-1"></i>
                                        <?php echo htmlspecialchars($currentUser['username']); ?>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="profile.php">
                                            <i class="fas fa-user me-2"></i>Profile
                                        </a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="logout.php">
                                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                                        </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- Content -->
                    <div class="p-4">
                        <!-- Alert Area -->
                        <div id="alertArea"></div>
                        
                        <!-- Profile Header -->
                        <div class="row mb-4">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body text-center py-5">
                                        <div class="profile-avatar mb-3">
                                            <i class="fas fa-user"></i>
                                        </div>
                                        <h3 class="mb-1"><?php echo htmlspecialchars($currentUser['full_name']); ?></h3>
                                        <p class="text-muted mb-2">@<?php echo htmlspecialchars($currentUser['username']); ?></p>
                                        <div class="d-flex justify-content-center gap-2 mb-3">
                                            <span class="badge bg-primary">
                                                <i class="fas fa-user-shield me-1"></i>
                                                <?php echo ucfirst($currentUser['role']); ?>
                                            </span>
                                            <span class="badge bg-secondary">
                                                <i class="fas fa-building me-1"></i>
                                                <?php echo htmlspecialchars($currentUser['department']); ?>
                                            </span>
                                        </div>
                                        <small class="text-muted">
                                            <i class="fas fa-calendar me-1"></i>
                                            Bergabung sejak <?php echo date('d F Y', strtotime($currentUser['created_at'])); ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Statistics removed for admin (upload-related info not applicable) -->
                        
                        <div class="row">
                            <!-- Profile Information -->
                            <div class="col-lg-6 mb-4">
                                <div class="card">
                                    <div class="card-header bg-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-user me-2"></i>Informasi Profil
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <form id="profileForm">
                                            <input type="hidden" name="action" value="update_profile">
                                            <input type="hidden" name="ajax" value="1">
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Username</label>
                                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($currentUser['username']); ?>" disabled>
                                                <small class="text-muted">Username tidak dapat diubah</small>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" name="full_name" value="<?php echo htmlspecialchars($currentUser['full_name']); ?>" required>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Email <span class="text-danger">*</span></label>
                                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($currentUser['email']); ?>" required>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Departemen</label>
                                                <input type="text" class="form-control" name="department" value="<?php echo htmlspecialchars($currentUser['department']); ?>">
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Role</label>
                                                <input type="text" class="form-control" value="<?php echo ucfirst($currentUser['role']); ?>" disabled>
                                                <small class="text-muted">Role ditentukan oleh administrator</small>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary w-100" id="profileBtn">
                                                <i class="fas fa-save me-2"></i>Simpan Perubahan
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Change Password -->
                            <div class="col-lg-6 mb-4">
                                <div class="card mb-4">
                                    <div class="card-header bg-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-key me-2"></i>Ubah Password
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <form id="passwordForm">
                                            <input type="hidden" name="action" value="update_password">
                                            <input type="hidden" name="ajax" value="1">
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Password Saat Ini <span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <input type="password" class="form-control" name="current_password" id="currentPassword" required>
                                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword(event,'currentPassword')">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Password Baru <span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <input type="password" class="form-control" name="new_password" id="newPassword" required minlength="6">
                                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword(event,'newPassword')">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                </div>
                                                <small class="text-muted">Minimal 6 karakter</small>
                                                <div class="password-strength mt-2 bg-secondary" id="passwordStrength"></div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">Konfirmasi Password Baru <span class="text-danger">*</span></label>
                                                <div class="input-group">
                                                    <input type="password" class="form-control" name="confirm_password" id="confirmPassword" required>
                                                    <button class="btn btn-outline-secondary" type="button" onclick="togglePassword(event,'confirmPassword')">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                </div>
                                                <small class="text-danger d-none" id="passwordMatch">Password tidak cocok!</small>
                                            </div>
                                            
                                            <button type="submit" class="btn btn-primary w-100" id="passwordBtn">
                                                <i class="fas fa-key me-2"></i>Ubah Password
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                
                                <!-- Account Info -->
                                <div class="card">
                                    <div class="card-header bg-white">
                                        <h6 class="mb-0">
                                            <i class="fas fa-info-circle me-2"></i>Informasi Akun
                                        </h6>
                                    </div>
                                    <div class="card-body p-0">
                                        <div class="info-row">
                                            <div class="info-label">Status Akun</div>
                                            <div>
                                                <span class="badge bg-success">
                                                    <i class="fas fa-check-circle me-1"></i>Aktif
                                                </span>
                                            </div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Terdaftar Sejak</div>
                                            <div><?php echo date('d F Y, H:i', strtotime($currentUser['created_at'])); ?></div>
                                        </div>
                                        <div class="info-row">
                                            <div class="info-label">Login Terakhir</div>
                                            <div>Sekarang</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Recent uploads removed for admin (not applicable) -->
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle password visibility (menerima event agar kompatibel ketika dipanggil dari onclick)
        function togglePassword(e, fieldId) {
            e = e || window.event;
            const field = document.getElementById(fieldId);
            // cari tombol pemanggil (paling dekat) secara aman
            const btn = e.currentTarget || e.srcElement || document.activeElement;
            const icon = btn ? btn.querySelector('i') : null;

            if (!field) return;

            if (field.type === 'password') {
                field.type = 'text';
                if (icon) { icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash'); }
            } else {
                field.type = 'password';
                if (icon) { icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye'); }
            }
        }

        // Password strength meter
        document.getElementById('newPassword').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('passwordStrength');
            let strength = 0;
            
            if (password.length >= 6) strength++;
            if (password.length >= 10) strength++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            if (/\d/.test(password)) strength++;
            if (/[^a-zA-Z\d]/.test(password)) strength++;
            
            const colors = ['#dc3545', '#fd7e14', '#ffc107', '#28a745', '#20c997'];
            const widths = ['20%', '40%', '60%', '80%', '100%'];
            
            strengthBar.style.backgroundColor = colors[strength - 1] || '#6c757d';
            strengthBar.style.width = widths[strength - 1] || '0%';
        });

        // Password match validation
        document.getElementById('confirmPassword').addEventListener('input', function() {
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = this.value;
            const matchWarning = document.getElementById('passwordMatch');
            
            if (confirmPassword && newPassword !== confirmPassword) {
                matchWarning.classList.remove('d-none');
            } else {
                matchWarning.classList.add('d-none');
            }
        });

        // Profile form submission
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = document.getElementById('profileBtn');
            const originalBtnText = submitBtn.innerHTML;
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Menyimpan...';
            
            fetch('profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showAlert(data.success ? 'success' : 'danger', data.message);
                
                if (data.success) {
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnText;
                }
            })
            .catch(error => {
                showAlert('danger', 'Terjadi kesalahan sistem');
                console.error('Error:', error);
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            });
        });

        // Password form submission
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            if (newPassword !== confirmPassword) {
                showAlert('danger', 'Password baru dan konfirmasi password tidak cocok');
                return;
            }
            
            const formData = new FormData(this);
            const submitBtn = document.getElementById('passwordBtn');
            const originalBtnText = submitBtn.innerHTML;
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Mengubah...';
            
            fetch('profile.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showAlert(data.success ? 'success' : 'danger', data.message);
                
                if (data.success) {
                    this.reset();
                    document.getElementById('passwordStrength').style.width = '0%';
                }
                
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            })
            .catch(error => {
                showAlert('danger', 'Terjadi kesalahan sistem');
                console.error('Error:', error);
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            });
        });

        // Show alert
        function showAlert(type, message) {
            const alertHtml = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
            document.getElementById('alertArea').innerHTML = alertHtml;
            
            // Scroll to top
            window.scrollTo({ top: 0, behavior: 'smooth' });
            
            // Auto dismiss after 5 seconds
            setTimeout(() => {
                const alert = document.querySelector('.alert');
                if (alert) {
                    alert.classList.remove('show');
                    setTimeout(() => alert.remove(), 150);
                }
            }, 5000);
        }
    </script>
</body>
</html>

