<?php
/**
 * Script untuk inisialisasi kategori default
 * Jalankan sekali untuk membuat kategori awal
 */

require_once 'config/config.php';
require_once 'config/database.php';

echo "==============================================\n";
echo "   INISIALISASI KATEGORI DEFAULT\n";
echo "==============================================\n\n";

// Koneksi database
$database = new Database();
$conn = $database->getConnection();

try {
    // Cek apakah sudah ada kategori
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM categories");
    $stmt->execute();
    $result = $stmt->fetch();
    
    if ($result['count'] > 0) {
        echo "⚠ PERINGATAN: Sudah ada {$result['count']} kategori di database.\n";
        echo "Apakah Anda ingin menghapus semua kategori yang ada dan membuat ulang? (y/n): ";
        $handle = fopen("php://stdin", "r");
        $line = fgets($handle);
        if (trim($line) != 'y') {
            echo "Dibatalkan.\n";
            exit;
        }
        fclose($handle);
        
        // Hapus kategori lama
        echo "\nMenghapus kategori lama...\n";
        $stmt = $conn->prepare("DELETE FROM categories");
        $stmt->execute();
        echo "✓ Kategori lama berhasil dihapus.\n\n";
    }
    
    // Data kategori default
    $defaultCategories = [
        [
            'name' => 'DEKIDAKA DCM',
            'description' => 'Kategori untuk dokumen DEKIDAKA DCM',
            'color' => '#FF6B6B'
        ],
        [
            'name' => 'INGOT CHARGING',
            'description' => 'Kategori untuk dokumen INGOT CHARGING',
            'color' => '#4ECDC4'
        ],
        [
            'name' => 'DEBURING',
            'description' => 'Kategori untuk dokumen DEBURING',
            'color' => '#45B7D1'
        ],
        [
            'name' => 'SHOTBLASTING',
            'description' => 'Kategori untuk dokumen SHOTBLASTING',
            'color' => '#FFA07A'
        ],
        [
            'name' => 'T5',
            'description' => 'Kategori untuk dokumen T5',
            'color' => '#98D8C8'
        ]
    ];
    
    // Insert kategori baru
    echo "Menambahkan kategori baru...\n";
    $stmt = $conn->prepare("INSERT INTO categories (name, description, color) VALUES (?, ?, ?)");
    
    foreach ($defaultCategories as $category) {
        $stmt->execute([
            $category['name'],
            $category['description'],
            $category['color']
        ]);
        echo "✓ Kategori '{$category['name']}' berhasil ditambahkan (Warna: {$category['color']})\n";
    }
    
    echo "\n==============================================\n";
    echo "  INISIALISASI KATEGORI BERHASIL!\n";
    echo "==============================================\n";
    
    // Tampilkan kategori yang ada sekarang
    echo "\nKategori yang tersedia:\n\n";
    $stmt = $conn->prepare("SELECT * FROM categories ORDER BY id ASC");
    $stmt->execute();
    $categories = $stmt->fetchAll();
    
    foreach ($categories as $cat) {
        echo "  ID: {$cat['id']}\n";
        echo "  Nama: {$cat['name']}\n";
        echo "  Deskripsi: {$cat['description']}\n";
        echo "  Warna: {$cat['color']}\n";
        echo "  ---\n";
    }
    
    write_log("Default categories initialized successfully", 'INFO');
    
} catch (PDOException $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    write_log("Init categories error: " . $e->getMessage(), 'ERROR');
}

echo "\nSelesai! Anda sekarang dapat mengakses halaman categories.php untuk mengelola kategori.\n";
?>

