<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/Document.php';
require_once 'classes/Category.php';
require_once 'classes/User.php';

// Check login
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

$currentUser = $auth->getCurrentUser();
$document = new Document();
$category = new Category();
$user = new User();

// Get statistics
$dept = $auth->isSuperAdmin() ? null : $currentUser['department'];
$stats = $document->getDocumentStats($dept);
$categories = $category->getAllCategories();
$totalActiveUsers = $user->getTotalActiveUsers();

// Get recent documents (filter by user department unless superadmin)
$recentDocs = $document->searchDocuments('', null, null, null, null, null, $dept, 1);
$recentDocuments = array_slice($recentDocs['documents'], 0, 5);

// Get documents by category for chart
$categoryStats = $category->getCategoryStats($dept);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        /* Sidebar responsive fixed behavior */
        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                min-height: 100vh;
                background: #f8f9fa;
            }
            /* Pastikan kolom grid sidebar memiliki lebar sama dengan sidebar fixed
               agar tidak muncul celah putih antara sidebar dan konten. */
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        /* Small screens: sidebar flows normally */
        @media (max-width: 767.98px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                overflow: visible;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: 0;
                background: #f8f9fa;
            }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        .stat-card {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            color: white;
        }
        .stat-card .stat-icon {
            font-size: 2.5rem;
            opacity: 0.8;
        }
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
        .user-info {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .document-item {
            border-left: 4px solid #495057;
            padding: 0.75rem;
            margin-bottom: 0.5rem;
            background: white;
            border-radius: 0 10px 10px 0;
            transition: all 0.3s ease;
        }
        .document-item:hover {
            transform: translateX(5px);
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        }
        .category-badge {
            font-size: 0.75rem;
            padding: 0.25rem 0.5rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0 fixed">
                <div class="sidebar p-3">
                    <div class="user-info text-center">
                        <i class="fas fa-user-circle fa-3x mb-2"></i>
                        <h6><?php echo htmlspecialchars($currentUser['full_name']); ?></h6>
                        <small class="text-white-50">
                            <i class="fas fa-building me-1"></i>
                            <?php echo htmlspecialchars($currentUser['department']); ?>
                        </small>
                        <div class="mt-2">
                            <span class="badge bg-light text-dark">
                                <i class="fas fa-user-shield me-1"></i>
                                <?php echo ucfirst($currentUser['role']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link active" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="documents.php">
                            <i class="fas fa-file-alt me-2"></i>Dokumen
                        </a>
                        <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="upload.php">
                                <i class="fas fa-upload me-2"></i>Upload
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search me-2"></i>Pencarian
                        </a>
                        <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags me-2"></i>Kategori
                            </a>
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-line me-2"></i>Laporan
                            </a>
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-cog me-2"></i>Profile
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <span class="navbar-brand">
                                <i class="fas fa-file-alt me-2"></i>
                                <?php echo APP_NAME; ?>
                            </span>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo date('d/m/Y H:i'); ?>
                                </span>
                                <div class="dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                        <i class="fas fa-user-circle me-1"></i>
                                        <?php echo htmlspecialchars($currentUser['username']); ?>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="profile.php">
                                            <i class="fas fa-user me-2"></i>Profile
                                        </a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="logout.php">
                                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                                        </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- Content -->
                    <div class="p-4">
                        <div class="row mb-4">
                            <div class="col-12">
                                <h2 class="mb-3">
                                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                                </h2>
                                <p class="text-muted">Selamat datang di sistem manajemen dokumen</p>
                            </div>
                        </div>
                        
                        <!-- Statistics Cards -->
                        <div class="row mb-4">
                            <div class="col-md-3 mb-3">
                                <div class="card stat-card">
                                    <div class="card-body text-center">
                                        <div class="stat-icon mb-2">
                                            <i class="fas fa-file-alt"></i>
                                        </div>
                                        <h3 class="mb-1"><?php echo number_format($stats['total_documents'] ?? 0); ?></h3>
                                        <p class="mb-0">Total Dokumen</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="card stat-card">
                                    <div class="card-body text-center">
                                        <div class="stat-icon mb-2">
                                            <i class="fas fa-tags"></i>
                                        </div>
                                        <h3 class="mb-1"><?php echo count($categories); ?></h3>
                                        <p class="mb-0">Kategori</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="card stat-card">
                                    <div class="card-body text-center">
                                        <div class="stat-icon mb-2">
                                            <i class="fas fa-users"></i>
                                        </div>
                                        <h3 class="mb-1"><?php echo number_format($totalActiveUsers); ?></h3>
                                        <p class="mb-0">Users Aktif</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 mb-3">
                                <div class="card stat-card">
                                    <div class="card-body text-center">
                                        <div class="stat-icon mb-2">
                                            <i class="fas fa-calendar"></i>
                                        </div>
                                        <h3 class="mb-1"><?php echo date('M Y'); ?></h3>
                                        <p class="mb-0">Periode</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <!-- Recent Documents -->
                            <div class="col-lg-8 mb-4">
                                <div class="card">
                                    <div class="card-header bg-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-clock me-2"></i>Dokumen Terbaru
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($recentDocuments)): ?>
                                            <div class="text-center text-muted py-4">
                                                <i class="fas fa-file-alt fa-3x mb-3"></i>
                                                <p>Belum ada dokumen yang diupload</p>
                                                <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                                                    <a href="upload.php" class="btn btn-primary">
                                                        <i class="fas fa-upload me-2"></i>Upload Dokumen Pertama
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        <?php else: ?>
                                            <?php foreach ($recentDocuments as $doc): ?>
                                                <div class="document-item">
                                                    <div class="d-flex justify-content-between align-items-start">
                                                        <div class="flex-grow-1">
                                                            <h6 class="mb-1">
                                                                <i class="fas fa-file-alt me-2 text-primary"></i>
                                                                <?php echo htmlspecialchars($doc['title']); ?>
                                                            </h6>
                                                            <p class="mb-1 text-muted small">
                                                                <?php echo htmlspecialchars($doc['description']); ?>
                                                            </p>
                                                            <div class="d-flex align-items-center gap-2">
                                                                <span class="badge category-badge" 
                                                                      style="background-color: <?php echo $doc['category_color']; ?>; color: white;">
                                                                    <?php echo htmlspecialchars($doc['category_name']); ?>
                                                                </span>
                                                                <?php if ($doc['shift']): ?>
                                                                    <small class="text-muted">
                                                                        <i class="fas fa-clock me-1"></i>
                                                                        Shift <?php echo ucfirst(htmlspecialchars($doc['shift'])); ?>
                                                                    </small>
                                                                <?php endif; ?>
                                                                <?php if ($doc['page_count']): ?>
                                                                    <small class="text-muted">
                                                                        <i class="fas fa-file-pdf me-1"></i>
                                                                        <?php echo htmlspecialchars($doc['page_count']); ?> halaman
                                                                    </small>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                        <div class="text-end">
                                                            <small class="text-muted d-block">
                                                                <?php echo date('d/m/Y H:i', strtotime($doc['upload_date'])); ?>
                                                            </small>
                                                            <small class="text-muted">
                                                                by <?php echo htmlspecialchars($doc['uploader_name']); ?>
                                                            </small>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                            <div class="text-center mt-3">
                                                <a href="documents.php" class="btn btn-outline-primary btn-sm">
                                                    Lihat Semua Dokumen
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Quick Actions & Charts -->
                            <div class="col-lg-4 mb-4">
                                <!-- Quick Actions -->
                                <div class="card mb-4">
                                    <div class="card-header bg-white">
                                        <h6 class="mb-0">
                                            <i class="fas fa-bolt me-2"></i>Aksi Cepat
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-grid gap-2">
                                            <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                                                <a href="upload.php" class="btn btn-primary">
                                                    <i class="fas fa-upload me-2"></i>Upload Dokumen
                                                </a>
                                            <?php endif; ?>
                                            <a href="search.php" class="btn btn-outline-primary">
                                                <i class="fas fa-search me-2"></i>Cari Dokumen
                                            </a>
                                            <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                                                <a href="categories.php" class="btn btn-outline-success">
                                                    <i class="fas fa-tags me-2"></i>Kelola Kategori
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Category Chart -->
                                <div class="card">
                                    <div class="card-header bg-white">
                                        <h6 class="mb-0">
                                            <i class="fas fa-chart-pie me-2"></i>Dokumen per Kategori
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="categoryChart" width="300" height="200"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Category Chart
        const ctx = document.getElementById('categoryChart').getContext('2d');
        const categoryData = <?php echo json_encode($categoryStats); ?>;
        
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: categoryData.map(item => item.name),
                datasets: [{
                    data: categoryData.map(item => item.document_count),
                    backgroundColor: categoryData.map(item => item.color),
                    borderWidth: 2,
                    borderColor: '#fff'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
