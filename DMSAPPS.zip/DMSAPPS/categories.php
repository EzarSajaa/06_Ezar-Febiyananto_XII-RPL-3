<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/Category.php';

// Check login dan admin
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

if (!($auth->isAdmin() || $auth->isSuperAdmin())) {
    redirect('index.php');
}

$currentUser = $auth->getCurrentUser();
$category = new Category();

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'create') {
        $result = $category->createCategory(
            $_POST['name'],
            $_POST['description'],
            $_POST['color']
        );
        echo json_encode($result);
        exit;
    }
    
    if ($_POST['action'] === 'update') {
        $result = $category->updateCategory(
            $_POST['id'],
            $_POST['name'],
            $_POST['description'],
            $_POST['color']
        );
        echo json_encode($result);
        exit;
    }
    
    if ($_POST['action'] === 'delete') {
        $result = $category->deleteCategory($_POST['id']);
        echo json_encode($result);
        exit;
    }
}

// Get all categories
$categories = $category->getAllCategories();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                min-height: 100vh;
                background: #f8f9fa;
            }
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 767.98px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                overflow: visible;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: 0;
                background: #f8f9fa;
            }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }
        .user-info {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .category-color-preview {
            width: 30px;
            height: 30px;
            border-radius: 5px;
            display: inline-block;
            border: 2px solid #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
        }
        .category-card {
            border-left: 4px solid;
            transition: all 0.3s ease;
        }
        .category-card:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .color-option {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
            border: 3px solid transparent;
            transition: all 0.3s ease;
            display: inline-block;
            margin: 5px;
        }
        .color-option:hover {
            transform: scale(1.1);
        }
        .color-option.selected {
            border-color: #495057;
            box-shadow: 0 0 0 3px rgba(73, 80, 87, 0.2);
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="user-info text-center">
                        <i class="fas fa-user-circle fa-3x mb-2"></i>
                        <h6><?php echo htmlspecialchars($currentUser['full_name']); ?></h6>
                        <small class="text-white-50">
                            <i class="fas fa-building me-1"></i>
                            <?php echo htmlspecialchars($currentUser['department']); ?>
                        </small>
                        <div class="mt-2">
                            <span class="badge bg-light text-dark">
                                <i class="fas fa-user-shield me-1"></i>
                                <?php echo ucfirst($currentUser['role']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="documents.php">
                            <i class="fas fa-file-alt me-2"></i>Dokumen
                        </a>
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search me-2"></i>Pencarian
                        </a>
                        <a class="nav-link active" href="categories.php">
                            <i class="fas fa-tags me-2"></i>Kategori
                        </a>
                        <a class="nav-link" href="users.php">
                            <i class="fas fa-users me-2"></i>Users
                        </a>
                        <a class="nav-link" href="reports.php">
                            <i class="fas fa-chart-line me-2"></i>Laporan
                        </a>
                        <a class="nav-link" href="backup.php">
                            <i class="fas fa-database me-2"></i>Backup
                        </a>
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-cog me-2"></i>Profile
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <span class="navbar-brand">
                                <i class="fas fa-tags me-2"></i>
                                Kelola Kategori
                            </span>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo date('d/m/Y H:i'); ?>
                                </span>
                                <div class="dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                        <i class="fas fa-user-circle me-1"></i>
                                        <?php echo htmlspecialchars($currentUser['username']); ?>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="profile.php">
                                            <i class="fas fa-user me-2"></i>Profile
                                        </a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="logout.php">
                                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                                        </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- Content -->
                    <div class="p-4">
                        <div class="row mb-4">
                            <div class="col-12">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <h2 class="mb-1">
                                            <i class="fas fa-tags me-2"></i>Kelola Kategori
                                        </h2>
                                        <p class="text-muted mb-0">Kelola kategori dokumen untuk mengorganisir dokumen produksi</p>
                                    </div>
                                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick="openCreateModal()">
                                        <i class="fas fa-plus me-2"></i>Tambah Kategori
                                    </button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Alert Area -->
                        <div id="alertArea"></div>
                        
                        <!-- Categories List -->
                        <div class="row">
                            <?php if (empty($categories)): ?>
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body text-center py-5">
                                            <i class="fas fa-tags fa-4x text-muted mb-3"></i>
                                            <h5>Belum Ada Kategori</h5>
                                            <p class="text-muted">Mulai dengan menambahkan kategori pertama untuk mengorganisir dokumen Anda</p>
                                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick="openCreateModal()">
                                                <i class="fas fa-plus me-2"></i>Tambah Kategori Pertama
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            <div class="table-responsive">
                                                <table class="table table-hover align-middle">
                                                    <thead>
                                                        <tr>
                                                            <th width="5%">#</th>
                                                            <th width="10%">Warna</th>
                                                            <th width="25%">Nama Kategori</th>
                                                            <th width="35%">Deskripsi</th>
                                                            <th width="10%" class="text-center">Jumlah Dokumen</th>
                                                            <th width="15%" class="text-center">Aksi</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody id="categoryList">
                                                        <?php foreach ($categories as $index => $cat): ?>
                                                            <tr>
                                                                <td><?php echo $index + 1; ?></td>
                                                                <td>
                                                                    <div class="category-color-preview" style="background-color: <?php echo htmlspecialchars($cat['color']); ?>"></div>
                                                                </td>
                                                                <td>
                                                                    <strong><?php echo htmlspecialchars($cat['name']); ?></strong>
                                                                </td>
                                                                <td>
                                                                    <small class="text-muted"><?php echo htmlspecialchars($cat['description']); ?></small>
                                                                </td>
                                                                <td class="text-center">
                                                                    <span class="badge bg-secondary">
                                                                        <?php echo $cat['document_count']; ?> dokumen
                                                                    </span>
                                                                </td>
                                                                <td class="text-center">
                                                                    <div class="btn-group btn-group-sm" role="group">
                                                                        <button class="btn btn-outline-primary" data-cat="<?php echo htmlspecialchars(json_encode($cat), ENT_QUOTES); ?>" onclick="openEditModal(this.getAttribute('data-cat'))">
                                                                            <i class="fas fa-edit"></i>
                                                                        </button>
                                                                        <button class="btn btn-outline-danger" onclick="deleteCategory(<?php echo $cat['id']; ?>, '<?php echo htmlspecialchars($cat['name'], ENT_QUOTES); ?>')">
                                                                            <i class="fas fa-trash"></i>
                                                                        </button>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Category Modal -->
    <div class="modal fade" id="categoryModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitle">
                        <i class="fas fa-plus me-2"></i>Tambah Kategori
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="categoryForm">
                    <div class="modal-body">
                        <input type="hidden" id="categoryId" name="id">
                        <input type="hidden" id="formAction" name="action" value="create">
                        <input type="hidden" name="ajax" value="1">
                        
                        <div class="mb-3">
                            <label class="form-label">Nama Kategori <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="categoryName" name="name" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="categoryDescription" name="description" rows="3"></textarea>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Pilih Warna <span class="text-danger">*</span></label>
                            <input type="hidden" id="categoryColor" name="color" value="#FF6B6B" required>
                            <div class="d-flex flex-wrap gap-2" id="colorPicker">
                                <div class="color-option selected" style="background-color: #FF6B6B" onclick="selectColor('#FF6B6B', this)"></div>
                                <div class="color-option" style="background-color: #4ECDC4" onclick="selectColor('#4ECDC4', this)"></div>
                                <div class="color-option" style="background-color: #45B7D1" onclick="selectColor('#45B7D1', this)"></div>
                                <div class="color-option" style="background-color: #FFA07A" onclick="selectColor('#FFA07A', this)"></div>
                                <div class="color-option" style="background-color: #98D8C8" onclick="selectColor('#98D8C8', this)"></div>
                                <div class="color-option" style="background-color: #F7DC6F" onclick="selectColor('#F7DC6F', this)"></div>
                                <div class="color-option" style="background-color: #BB8FCE" onclick="selectColor('#BB8FCE', this)"></div>
                                <div class="color-option" style="background-color: #85C1E2" onclick="selectColor('#85C1E2', this)"></div>
                                <div class="color-option" style="background-color: #F8B739" onclick="selectColor('#F8B739', this)"></div>
                                <div class="color-option" style="background-color: #52BE80" onclick="selectColor('#52BE80', this)"></div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary" id="submitBtn">
                            <i class="fas fa-save me-2"></i>Simpan
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Color selection
        function selectColor(color, element) {
            document.querySelectorAll('.color-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            element.classList.add('selected');
            document.getElementById('categoryColor').value = color;
        }

        // Open create modal
        function openCreateModal() {
            document.getElementById('modalTitle').innerHTML = '<i class="fas fa-plus me-2"></i>Tambah Kategori';
            document.getElementById('categoryForm').reset();
            document.getElementById('formAction').value = 'create';
            document.getElementById('categoryId').value = '';
            document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save me-2"></i>Simpan';
            
            // Reset color selection
            document.querySelectorAll('.color-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            document.querySelector('.color-option').classList.add('selected');
            document.getElementById('categoryColor').value = '#FF6B6B';
        }

        // Open edit modal (accepts either object or JSON string)
        function openEditModal(category) {
            try {
                if (typeof category === 'string') {
                    category = JSON.parse(category);
                }
            } catch (e) {
                console.error('Gagal membaca data kategori:', e);
                return;
            }

            document.getElementById('modalTitle').innerHTML = '<i class="fas fa-edit me-2"></i>Edit Kategori';
            document.getElementById('formAction').value = 'update';
            document.getElementById('categoryId').value = category.id;
            document.getElementById('categoryName').value = category.name;
            document.getElementById('categoryDescription').value = category.description;
            document.getElementById('categoryColor').value = category.color;
            document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save me-2"></i>Update';

            // Set selected color
            document.querySelectorAll('.color-option').forEach(opt => {
                opt.classList.remove('selected');
                if (opt.style.backgroundColor === category.color || rgbToHex(opt.style.backgroundColor) === category.color.toUpperCase()) {
                    opt.classList.add('selected');
                }
            });

            // Show modal
            const modal = new bootstrap.Modal(document.getElementById('categoryModal'));
            modal.show();
        }

        // Convert RGB to Hex
        function rgbToHex(rgb) {
            const result = rgb.match(/\d+/g);
            if (!result) return rgb;
            return '#' + result.map(x => {
                const hex = parseInt(x).toString(16);
                return hex.length === 1 ? '0' + hex : hex;
            }).join('').toUpperCase();
        }

        // Delete category
        function deleteCategory(id, name) {
            if (confirm(`Apakah Anda yakin ingin menghapus kategori "${name}"?`)) {
                const formData = new FormData();
                formData.append('action', 'delete');
                formData.append('id', id);
                formData.append('ajax', '1');
                
                fetch('categories.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    showAlert(data.success ? 'success' : 'danger', data.message);
                    if (data.success) {
                        setTimeout(() => location.reload(), 1500);
                    }
                })
                .catch(error => {
                    showAlert('danger', 'Terjadi kesalahan sistem');
                    console.error('Error:', error);
                });
            }
        }

        // Handle form submission
        document.getElementById('categoryForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = document.getElementById('submitBtn');
            const originalBtnText = submitBtn.innerHTML;
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Menyimpan...';
            
            fetch('categories.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showAlert(data.success ? 'success' : 'danger', data.message);
                
                if (data.success) {
                    setTimeout(() => {
                        location.reload();
                    }, 1500);
                } else {
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalBtnText;
                }
            })
            .catch(error => {
                showAlert('danger', 'Terjadi kesalahan sistem');
                console.error('Error:', error);
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            });
        });

        // Show alert
        function showAlert(type, message) {
            const alertHtml = `
                <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'} me-2"></i>
                    ${message}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
            document.getElementById('alertArea').innerHTML = alertHtml;
            
            // Auto dismiss after 5 seconds
            setTimeout(() => {
                const alert = document.querySelector('.alert');
                if (alert) {
                    alert.classList.remove('show');
                    setTimeout(() => alert.remove(), 150);
                }
            }, 5000);
        }
    </script>
</body>
</html>

