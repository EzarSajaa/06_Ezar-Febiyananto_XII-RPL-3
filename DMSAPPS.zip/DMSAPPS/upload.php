<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/Document.php';
require_once 'classes/Category.php';

// Check login
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

// Blokir akses upload untuk admin (termasuk superadmin) — hanya user biasa yang boleh upload
if ($auth->isAdmin() || $auth->isSuperAdmin()) {
    redirect('documents.php');
}

$currentUser = $auth->getCurrentUser();
$document = new Document();
$category = new Category();

$error = '';
$success = '';

// Get categories for dropdown
$categories = $category->getCategoriesForDropdown();

// Get active departments for dropdown
$departments = $document->getActiveDepartments();


// Helper: hitung jumlah halaman PDF secara sederhana
function count_pdf_pages($filePath) {
    if (!file_exists($filePath)) return 0;
    $data = @file_get_contents($filePath);
    if ($data === false) return 0;

    // Metode 1: hitung occurrence '/Type /Page'
    $count = preg_match_all('/\/Type\s*\/Page\b/i', $data, $m);
    if ($count && $count > 0) {
        return $count;
    }

    // Metode 2 (fallback): ambil nilai /Count (ambil nilai maksimum yang ditemukan)
    if (preg_match_all('/\/Count\s+(\d+)/i', $data, $m2)) {
        if (!empty($m2[1])) {
            return (int) max($m2[1]);
        }
    }

    // Default
    return 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF token
    if (!validate_csrf_token($_POST['csrf_token'] ?? '')) {
        $error = 'Token keamanan tidak valid';
    } else {
        $title = sanitize_input($_POST['title'] ?? '');
        $description = sanitize_input($_POST['description'] ?? '');
        $categoryId = (int)($_POST['category_id'] ?? 0);
        $shift = sanitize_input($_POST['shift'] ?? '');
        $pageCount = sanitize_input($_POST['page_count'] ?? '');
    $productionDate = sanitize_input($_POST['production_date'] ?? '');
    // tags dihapus, tidak digunakan lagi
    $tags = '';
        // Department tujuan selalu mengikuti department user yang login
        $targetDepartment = $currentUser['department'];
        
        // Validation
        if (empty($title)) {
            $error = 'Judul dokumen harus diisi';
        } elseif (empty($categoryId)) {
            $error = 'Kategori harus dipilih';
        } elseif (empty($targetDepartment)) {
            $error = 'Department user tidak ditemukan, hubungi admin';
        } elseif (!isset($_FILES['document']) || $_FILES['document']['error'] === UPLOAD_ERR_NO_FILE) {
            $error = 'File dokumen harus dipilih';
        } else {
            // Validasi jumlah halaman jika file PDF diupload dan page_count diisi
            $uploadedFile = $_FILES['document'];
            $detectedPages = 0;
            $extension = strtolower(pathinfo($uploadedFile['name'], PATHINFO_EXTENSION));
            $skipUpload = false;

            if ($extension === 'pdf' && !empty($pageCount)) {
                // Buat salinan sementara file ke lokasi tmp untuk membaca isinya (gunakan copy agar file upload asli tetap ada)
                $tmpPath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . uniqid('upload_') . '.' . $extension;
                if (@copy($uploadedFile['tmp_name'], $tmpPath)) {
                    $detectedPages = count_pdf_pages($tmpPath);
                } else {
                    // Jika gagal copy, fallback baca langsung dari tmp_name asli
                    $detectedPages = count_pdf_pages($uploadedFile['tmp_name']);
                    // pastikan tmpPath tidak dianggap valid
                    $tmpPath = '';
                }

                // Bandingkan sebagai integer
                if ((int)$detectedPages !== (int)$pageCount) {
                    $error = "Jumlah halaman tidak sesuai. Terdeteksi: {$detectedPages} halaman, namun input: {$pageCount}.";
                    // jika file sudah disimpan di temp, hapus agar tidak menumpuk
                    if (!empty($tmpPath) && file_exists($tmpPath)) {
                        @unlink($tmpPath);
                    }
                    // tandai untuk skip upload
                    $skipUpload = true;
                }
            }
            // Jika valid atau bukan PDF / page_count kosong, lanjutkan upload
            if (empty($skipUpload)) {
                $result = $document->uploadDocument(
                    $_FILES['document'],
                    $title,
                    $description,
                    $categoryId,
                    $shift,
                    $pageCount,
                    $productionDate,
                    $tags,
                    $currentUser['id'],
                    $targetDepartment
                );

                if ($result['success']) {
                    $success = $result['message'];
                    // Clear form data
                    $_POST = array();
                } else {
                    $error = $result['message'];
                }
                // Hapus salinan sementara jika ada
                if (!empty($tmpPath) && file_exists($tmpPath)) {
                    @unlink($tmpPath);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Dokumen - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                min-height: 100vh;
                background: #f8f9fa;
            }
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 767.98px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                overflow: visible;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: 0;
                background: #f8f9fa;
            }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
         .btn-primary {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            border: none;
            border-radius: 10px;
            padding: 12px 24px;
        }
        .file-upload-area {
            border: 2px dashed #dee2e6;
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        .file-upload-area:hover {
            border-color: #495057;
            background-color: #f8f9fa;
        }
        .file-upload-area.dragover {
            border-color: #495057;
            background-color: #f8f9fa;
        }
        .navbar-brand {
            font-weight: 700;
            font-size: 1.5rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="text-center mb-4">
                        <i class="fas fa-file-alt fa-2x mb-2"></i>
                        <h6><?php echo APP_NAME; ?></h6>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="documents.php">
                            <i class="fas fa-file-alt me-2"></i>Dokumen
                        </a>
                        <a class="nav-link active" href="upload.php">
                            <i class="fas fa-upload me-2"></i>Upload
                        </a>
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search me-2"></i>Pencarian
                        </a>
                        <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags me-2"></i>Kategori
                            </a>
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-cog me-2"></i>Profile
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <span class="navbar-brand">
                                <i class="fas fa-upload me-2"></i>Upload Dokumen
                            </span>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-user me-1"></i>
                                    <?php echo htmlspecialchars($currentUser['full_name']); ?>
                                </span>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- Content -->
                    <div class="p-4">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">
                                <div class="card">
                                    <div class="card-header bg-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-upload me-2"></i>Upload Dokumen Baru
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if ($error): ?>
                                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                                <i class="fas fa-exclamation-triangle me-2"></i>
                                                <?php echo $error; ?>
                                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($success): ?>
                                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                                <i class="fas fa-check-circle me-2"></i>
                                                <?php echo $success; ?>
                                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <form method="POST" action="" enctype="multipart/form-data" id="uploadForm">
                                            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                            
                                            <div class="row">
                                                <div class="col-md-8">
                                                    <div class="mb-3">
                                                        <label for="title" class="form-label">
                                                            <i class="fas fa-heading me-2"></i>Judul Dokumen *
                                                        </label>
                                                        <input type="text" class="form-control" id="title" name="title" 
                                                               value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>" 
                                                               required placeholder="Masukkan judul dokumen">
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="mb-3">
                                                        <label for="category_id" class="form-label">
                                                            <i class="fas fa-tags me-2"></i>Kategori *
                                                        </label>
                                                        <select class="form-select" id="category_id" name="category_id" required>
                                                            <option value="">Pilih Kategori</option>
                                                            <?php foreach ($categories as $cat): ?>
                                                                <option value="<?php echo $cat['id']; ?>" 
                                                                        <?php echo ($_POST['category_id'] ?? '') == $cat['id'] ? 'selected' : ''; ?>>
                                                                    <?php echo htmlspecialchars($cat['name']); ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="description" class="form-label">
                                                    <i class="fas fa-align-left me-2"></i>Deskripsi
                                                </label>
                                                <textarea class="form-control" id="description" name="description" rows="3" 
                                                          placeholder="Masukkan deskripsi dokumen"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label class="form-label">
                                                    <i class="fas fa-building me-2"></i>Department Tujuan
                                                </label>
                                                <div class="form-control" readonly>
                                                    <?php echo htmlspecialchars($currentUser['department']); ?>
                                                </div>
                                                <input type="hidden" name="target_department" value="<?php echo htmlspecialchars($currentUser['department']); ?>">
                                                <small class="text-muted">
                                                    <i class="fas fa-info-circle me-1"></i>
                                                    Dokumen hanya akan terlihat oleh user/admin dari department ini
                                                </small>
                                            </div>
                                            
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="shift" class="form-label">
                                                            <i class="fas fa-clock me-2"></i>Shift
                                                        </label>
                                                        <select class="form-select" id="shift" name="shift">
                                                            <option value="">Pilih Shift</option>
                                                            <option value="pagi" <?php echo ($_POST['shift'] ?? '') == 'pagi' ? 'selected' : ''; ?>>Shift Pagi</option>
                                                            <option value="malam" <?php echo ($_POST['shift'] ?? '') == 'malam' ? 'selected' : ''; ?>>Shift Malam</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="page_count" class="form-label">
                                                            <i class="fas fa-file-pdf me-2"></i>Jumlah Halaman PDF
                                                        </label>
                                                        <input type="number" class="form-control" id="page_count" name="page_count" 
                                                               value="<?php echo htmlspecialchars($_POST['page_count'] ?? ''); ?>" 
                                                               placeholder="Contoh: 15" min="1">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label for="production_date" class="form-label">
                                                            <i class="fas fa-calendar me-2"></i>Tanggal Produksi
                                                        </label>
                                                        <input type="date" class="form-control" id="production_date" name="production_date" 
                                                               value="<?php echo htmlspecialchars($_POST['production_date'] ?? ''); ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <!-- Tags field telah dihapus karena tidak terpakai -->
                                            
                                            <div class="mb-4">
                                                <label class="form-label">
                                                    <i class="fas fa-file me-2"></i>File Dokumen *
                                                </label>
                                                <div class="file-upload-area" id="fileUploadArea">
                                                    <i class="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
                                                    <h5>Drag & Drop file di sini</h5>
                                                    <p class="text-muted">atau klik untuk memilih file</p>
                                                    <input type="file" class="form-control d-none" id="document" name="document" 
                                                           accept="<?php echo '.' . implode(',.', ALLOWED_EXTENSIONS); ?>" required>
                                                    <div class="mt-2">
                                                        <small class="text-muted">
                                                            Format yang diizinkan: <?php echo strtoupper(implode(', ', ALLOWED_EXTENSIONS)); ?><br>
                                                            Ukuran maksimal: <?php echo format_file_size(MAX_FILE_SIZE); ?>
                                                        </small>
                                                    </div>
                                                </div>
                                                <div id="fileInfo" class="mt-2 d-none">
                                                    <div class="alert alert-info">
                                                        <i class="fas fa-file me-2"></i>
                                                        <span id="fileName"></span>
                                                        <button type="button" class="btn-close float-end" onclick="clearFile()"></button>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between">
                                                <a href="index.php" class="btn btn-outline-secondary">
                                                    <i class="fas fa-arrow-left me-2"></i>Kembali
                                                </a>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="fas fa-upload me-2"></i>Upload Dokumen
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // File upload handling
        const fileUploadArea = document.getElementById('fileUploadArea');
        const fileInput = document.getElementById('document');
        const fileInfo = document.getElementById('fileInfo');
        const fileName = document.getElementById('fileName');
        
        // Click to select file
        fileUploadArea.addEventListener('click', () => {
            fileInput.click();
        });
        
        // Drag and drop
        fileUploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            fileUploadArea.classList.add('dragover');
        });
        
        fileUploadArea.addEventListener('dragleave', () => {
            fileUploadArea.classList.remove('dragover');
        });
        
        fileUploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            fileUploadArea.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                updateFileInfo(files[0]);
            }
        });
        
        // File input change
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                updateFileInfo(e.target.files[0]);
            }
        });
        
        function updateFileInfo(file) {
            fileName.textContent = `${file.name} (${formatFileSize(file.size)})`;
            fileInfo.classList.remove('d-none');
            fileUploadArea.style.display = 'none';
        }
        
        function clearFile() {
            fileInput.value = '';
            fileInfo.classList.add('d-none');
            fileUploadArea.style.display = 'block';
        }
        
        function formatFileSize(bytes) {
            if (bytes >= 1073741824) {
                return (bytes / 1073741824).toFixed(2) + ' GB';
            } else if (bytes >= 1048576) {
                return (bytes / 1048576).toFixed(2) + ' MB';
            } else if (bytes >= 1024) {
                return (bytes / 1024).toFixed(2) + ' KB';
            } else {
                return bytes + ' bytes';
            }
        }
        
        // Form validation
        document.getElementById('uploadForm').addEventListener('submit', function(e) {
            const title = document.getElementById('title').value.trim();
            const category = document.getElementById('category_id').value;
            const file = document.getElementById('document').files[0];
            
            if (!title) {
                e.preventDefault();
                alert('Judul dokumen harus diisi');
                document.getElementById('title').focus();
                return false;
            }
            
            if (!category) {
                e.preventDefault();
                alert('Kategori harus dipilih');
                document.getElementById('category_id').focus();
                return false;
            }
            
            if (!file) {
                e.preventDefault();
                alert('File dokumen harus dipilih');
                return false;
            }
            
            return true;
        });
    </script>
</body>
</html>
