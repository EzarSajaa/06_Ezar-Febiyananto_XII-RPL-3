<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/Document.php';

// Check login
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

$currentUser = $auth->getCurrentUser();
$document = new Document();

// Get document ID
$documentId = (int)($_GET['id'] ?? 0);

if (!$documentId) {
    redirect('search.php');
}

// Get document info and download
// Enforce access control: hanya uploader, admin, atau superadmin, atau user di department yang sama yang boleh download
$doc = $document->getDocumentById($documentId);
if (!$doc) {
    write_log("Download failed: document not found for id {$documentId} by user ID: " . $currentUser['id'], 'ERROR');
    redirect('search.php');
}

$filePath = $doc['file_path'];
$filename = $doc['original_filename'];
$fileType = $doc['file_type'];

// Determine access
// Restrict download: hanya admin atau superadmin yang dapat mendownload.
$isAdmin = $auth->isAdmin();
$isSuper = $auth->isSuperAdmin();
if (!($isAdmin || $isSuper)) {
    write_log("Unauthorized download attempt: doc {$documentId}, user: {$currentUser['id']} (role: {$currentUser['role']})", 'WARNING');
    $_SESSION['error'] = 'Anda tidak memiliki akses untuk mendownload dokumen ini';
    redirect('search.php');
}

// Check if file exists
if (!file_exists($filePath)) {
    write_log("File not found: {$filePath}", 'ERROR');
    redirect('search.php');
}

// Set headers for download
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . filesize($filePath));
header('Cache-Control: must-revalidate');
header('Pragma: public');

// Clear output buffer
if (ob_get_level()) {
    ob_end_clean();
}

// Read and output file
readfile($filePath);
exit;
?>
