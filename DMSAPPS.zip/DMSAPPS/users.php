<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/User.php';

$auth = new Auth();
if (!$auth->isLoggedIn()) { redirect('login.php'); }
if (!($auth->isAdmin() || $auth->isSuperAdmin())) { redirect('index.php'); }

$userService = new User();
$error = '';
$success = '';

// Handle actions (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!validate_csrf_token($csrf)) {
        $error = 'Token CSRF tidak valid';
    } else {
        $action = $_POST['action'] ?? '';
        if ($action === 'create') {
            $result = $userService->create($_POST);
            if ($result['success']) { $success = $result['message']; } else { $error = $result['message']; }
        } elseif ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $result = $userService->update($id, $_POST);
            if ($result['success']) { $success = $result['message']; } else { $error = $result['message']; }
        } elseif ($action === 'reset_password') {
            $id = (int)($_POST['id'] ?? 0);
            $newPassword = $_POST['new_password'] ?? '';
            $result = $userService->updatePassword($id, $newPassword);
            if ($result['success']) { $success = $result['message']; } else { $error = $result['message']; }
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $result = $userService->delete($id);
            if ($result['success']) { $success = $result['message']; } else { $error = $result['message']; }
        }
    }
}

$users = $userService->getAll();
$csrfToken = generate_csrf_token();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Users - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="mb-0"><i class="fas fa-users me-2"></i>Kelola Users</h3>
            <div class="d-flex gap-2">
                <a href="reports.php" class="btn btn-outline-primary"><i class="fas fa-chart-line me-1"></i>Laporan</a>
                <a href="index.php" class="btn btn-outline-secondary"><i class="fas fa-arrow-left me-1"></i>Kembali</a>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i><?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i><?php echo $success; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <strong>Tambah User</strong>
            </div>
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                    <input type="hidden" name="action" value="create">
                    <div class="col-md-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Nama Lengkap</label>
                        <input type="text" name="full_name" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Departemen</label>
                        <input type="text" name="department" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Role</label>
                        <select name="role" class="form-select">
                            <option value="user">user</option>
                            <option value="admin">admin</option>
                            <option value="superadmin">superadmin</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="col-md-12">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-plus me-1"></i>Tambah</button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <strong>Daftar Users</strong>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Username</th>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Departemen</th>
                            <th>Role</th>
                            <th>Aktif</th>
                            <th>Dibuat</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                            <tr><td colspan="9" class="text-center text-muted py-4">Belum ada user</td></tr>
                        <?php else: ?>
                            <?php foreach ($users as $i => $u): ?>
                                <tr>
                                    <td><?php echo $i + 1; ?></td>
                                    <td><?php echo htmlspecialchars($u['username']); ?></td>
                                    <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                                    <td><?php echo htmlspecialchars($u['department']); ?></td>
                                    <td>
                                        <?php
                                            $badgeClass = 'secondary';
                                            if ($u['role'] === 'admin') $badgeClass = 'danger';
                                            if ($u['role'] === 'superadmin') $badgeClass = 'dark';
                                        ?>
                                        <span class="badge bg-<?php echo $badgeClass; ?>"><?php echo htmlspecialchars($u['role']); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo $u['is_active']? 'success':'secondary'; ?>">
                                            <?php echo $u['is_active']? 'Aktif':'Nonaktif'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($u['created_at']))); ?></td>
                                    <td class="d-flex gap-1">
                                        <!-- Edit Modal Trigger -->
                                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editModal<?php echo $u['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <!-- Reset Password Modal Trigger -->
                                        <button class="btn btn-sm btn-outline-warning" data-bs-toggle="modal" data-bs-target="#pwdModal<?php echo $u['id']; ?>">
                                            <i class="fas fa-key"></i>
                                        </button>
                                        <!-- Delete -->
                                        <form method="POST" onsubmit="return confirm('Hapus user ini?');">
                                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>

                                <!-- Edit Modal -->
                                <div class="modal fade" id="editModal<?php echo $u['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"><i class="fas fa-edit me-2"></i>Edit User</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                                    <input type="hidden" name="action" value="update">
                                                    <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                                                    <div class="mb-3">
                                                        <label class="form-label">Nama Lengkap</label>
                                                        <input type="text" name="full_name" value="<?php echo htmlspecialchars($u['full_name']); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Email</label>
                                                        <input type="email" name="email" value="<?php echo htmlspecialchars($u['email']); ?>" class="form-control" required>
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Departemen</label>
                                                        <input type="text" name="department" value="<?php echo htmlspecialchars($u['department']); ?>" class="form-control">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="form-label">Role</label>
                                                        <select name="role" class="form-select">
                                                            <option value="user" <?php echo $u['role']==='user'? 'selected':''; ?>>user</option>
                                                            <option value="admin" <?php echo $u['role']==='admin'? 'selected':''; ?>>admin</option>
                                                            <option value="superadmin" <?php echo $u['role']==='superadmin'? 'selected':''; ?>>superadmin</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" id="active<?php echo $u['id']; ?>" name="is_active" value="1" <?php echo $u['is_active']? 'checked':''; ?>>
                                                        <label class="form-check-label" for="active<?php echo $u['id']; ?>">Aktif</label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <!-- Reset Password Modal -->
                                <div class="modal fade" id="pwdModal<?php echo $u['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <div class="modal-header">
                                                    <h5 class="modal-title"><i class="fas fa-key me-2"></i>Reset Password</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">
                                                    <input type="hidden" name="action" value="reset_password">
                                                    <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                                                    <div class="mb-3">
                                                        <label class="form-label">Password Baru</label>
                                                        <input type="password" name="new_password" class="form-control" required>
                                                        <small class="text-muted">Min <?php echo PASSWORD_MIN_LENGTH; ?> karakter</small>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-warning">Reset</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


