<?php
/**
 * Script untuk menambahkan field target_department ke tabel documents
 * Field ini digunakan untuk department-based access control
 */

require_once 'config/config.php';
require_once 'config/database.php';

echo "==============================================\n";
echo "   MENAMBAHKAN FIELD TARGET_DEPARTMENT\n";
echo "==============================================\n\n";

$database = new Database();
$conn = $database->getConnection();

try {
    // Cek apakah field target_department sudah ada
    $stmt = $conn->prepare("SHOW COLUMNS FROM documents LIKE 'target_department'");
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        echo "✓ Field 'target_department' sudah ada.\n";
    } else {
        echo "Menambahkan field 'target_department'...\n";
        $conn->exec("
            ALTER TABLE documents 
            ADD COLUMN target_department VARCHAR(100) DEFAULT NULL 
            COMMENT 'Department tujuan dokumen'
            AFTER uploaded_by
        ");
        echo "✓ Field 'target_department' berhasil ditambahkan.\n\n";
        
        // Add index for better performance
        try {
            $conn->exec("CREATE INDEX idx_target_department ON documents(target_department)");
            echo "✓ Index untuk 'target_department' berhasil ditambahkan.\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate key name') === false) {
                echo "⚠ Warning: Index gagal dibuat - " . $e->getMessage() . "\n";
            }
        }
    }
    
    // Update existing documents dengan department dari uploader
    echo "\nMengupdate dokumen yang sudah ada...\n";
    $stmt = $conn->query("
        UPDATE documents d
        INNER JOIN users u ON d.uploaded_by = u.id
        SET d.target_department = u.department
        WHERE d.target_department IS NULL
    ");
    $affected = $stmt->rowCount();
    echo "✓ {$affected} dokumen diupdate dengan department dari uploader.\n";
    
    echo "\n==============================================\n";
    echo "  UPDATE DATABASE BERHASIL!\n";
    echo "==============================================\n\n";
    
    echo "Field 'target_department' sekarang tersedia untuk:\n";
    echo "- Menentukan department tujuan dokumen\n";
    echo "- Filter dokumen berdasarkan department\n";
    echo "- Access control berdasarkan department\n\n";
    
    write_log("Field target_department added to documents table", 'INFO');
    
} catch (PDOException $e) {
    echo "❌ ERROR: " . $e->getMessage() . "\n";
    write_log("Add target_department field error: " . $e->getMessage(), 'ERROR');
}
?>

