<?php
require_once 'config/config.php';
require_once 'config/database.php';

class Auth {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    /**
     * Login user
     */
    public function login($username, $password) {
        try {
            $stmt = $this->conn->prepare("SELECT id, username, password, full_name, email, role, department FROM users WHERE username = ? AND is_active = 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                // Set session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['user_role'] = $user['role'];
                $_SESSION['department'] = $user['department'];
                $_SESSION['login_time'] = time();
                
                // Log login
                write_log("User {$username} logged in successfully", 'INFO');
                
                return [
                    'success' => true,
                    'message' => 'Login berhasil',
                    'user' => $user
                ];
            } else {
                write_log("Failed login attempt for username: {$username}", 'WARNING');
                return [
                    'success' => false,
                    'message' => 'Username atau password salah'
                ];
            }
        } catch (PDOException $e) {
            write_log("Login error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Logout user
     */
    public function logout() {
        $username = $_SESSION['username'] ?? 'Unknown';
        
        // Clear session
        session_unset();
        session_destroy();
        
        // Log logout
        write_log("User {$username} logged out", 'INFO');
        
        return [
            'success' => true,
            'message' => 'Logout berhasil'
        ];
    }
    
    /**
     * Check if user is logged in
     */
    public function isLoggedIn() {
        if (!isset($_SESSION['user_id'])) {
            return false;
        }
        
        // Check session timeout
        if (time() - $_SESSION['login_time'] > SESSION_TIMEOUT) {
            $this->logout();
            return false;
        }
        
        // Update login time
        $_SESSION['login_time'] = time();
        
        return true;
    }
    
    /**
     * Check if user is admin
     */
    public function isAdmin() {
        return $this->isLoggedIn() && $_SESSION['user_role'] === 'admin';
    }

    /**
     * Check if user is super admin (utama)
     */
    public function isSuperAdmin() {
        return $this->isLoggedIn() && $_SESSION['user_role'] === 'superadmin';
    }
    
    /**
     * Get current user info
     */
    public function getCurrentUser() {
        if (!$this->isLoggedIn()) {
            return null;
        }
        
        return [
            'id' => $_SESSION['user_id'],
            'username' => $_SESSION['username'],
            'full_name' => $_SESSION['full_name'],
            'email' => $_SESSION['email'],
            'role' => $_SESSION['user_role'],
            'department' => $_SESSION['department']
        ];
    }
    
    /**
     * Change password
     */
    public function changePassword($userId, $currentPassword, $newPassword) {
        try {
            // Verify current password
            $stmt = $this->conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if (!$user || !password_verify($currentPassword, $user['password'])) {
                return [
                    'success' => false,
                    'message' => 'Password saat ini salah'
                ];
            }
            
            // Validate new password
            if (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
                return [
                    'success' => false,
                    'message' => 'Password minimal ' . PASSWORD_MIN_LENGTH . ' karakter'
                ];
            }
            
            // Hash new password
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            
            // Update password
            $stmt = $this->conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $userId]);
            
            write_log("Password changed for user ID: {$userId}", 'INFO');
            
            return [
                'success' => true,
                'message' => 'Password berhasil diubah'
            ];
        } catch (PDOException $e) {
            write_log("Change password error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Create new user (admin only)
     */
    public function createUser($username, $password, $fullName, $email, $role, $department) {
        if (!($this->isAdmin() || $this->isSuperAdmin())) {
            return [
                'success' => false,
                'message' => 'Akses ditolak'
            ];
        }
        
        try {
            // Check if username exists
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                return [
                    'success' => false,
                    'message' => 'Username sudah ada'
                ];
            }
            
            // Check if email exists
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                return [
                    'success' => false,
                    'message' => 'Email sudah ada'
                ];
            }
            
            // Validate password
            if (strlen($password) < PASSWORD_MIN_LENGTH) {
                return [
                    'success' => false,
                    'message' => 'Password minimal ' . PASSWORD_MIN_LENGTH . ' karakter'
                ];
            }
            
            // Hash password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert user
            $stmt = $this->conn->prepare("INSERT INTO users (username, password, full_name, email, role, department) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $hashedPassword, $fullName, $email, $role, $department]);
            
            $userId = $this->conn->lastInsertId();
            write_log("New user created: {$username} by admin", 'INFO');
            
            return [
                'success' => true,
                'message' => 'User berhasil dibuat',
                'user_id' => $userId
            ];
        } catch (PDOException $e) {
            write_log("Create user error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Get all users (admin only)
     */
    public function getAllUsers() {
        if (!($this->isAdmin() || $this->isSuperAdmin())) {
            return [];
        }
        
        try {
            $stmt = $this->conn->prepare("SELECT id, username, full_name, email, role, department, created_at, is_active FROM users ORDER BY created_at DESC");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            write_log("Get users error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }
    
    /**
     * Update user status (admin only)
     */
    public function updateUserStatus($userId, $isActive) {
        if (!($this->isAdmin() || $this->isSuperAdmin())) {
            return [
                'success' => false,
                'message' => 'Akses ditolak'
            ];
        }
        
        try {
            $stmt = $this->conn->prepare("UPDATE users SET is_active = ? WHERE id = ?");
            $stmt->execute([$isActive ? 1 : 0, $userId]);
            
            write_log("User status updated: ID {$userId}, Active: " . ($isActive ? 'Yes' : 'No'), 'INFO');
            
            return [
                'success' => true,
                'message' => 'Status user berhasil diubah'
            ];
        } catch (PDOException $e) {
            write_log("Update user status error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
}
?>
