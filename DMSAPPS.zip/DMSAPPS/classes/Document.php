<?php
require_once 'config/config.php';
require_once 'config/database.php';

class Document {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    /**
     * Upload dokumen baru
     */
    public function uploadDocument($file, $title, $description, $categoryId, $shift, $pageCount, $productionDate, $tags, $userId, $targetDepartment = null) {
        try {
            // Validasi file
            $validation = $this->validateFile($file);
            if (!$validation['success']) {
                return $validation;
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = uniqid() . '_' . time() . '.' . $extension;
            
            // Create upload directory if not exists
            if (!is_dir(UPLOAD_DIR)) {
                mkdir(UPLOAD_DIR, 0755, true);
            }
            
            // Move uploaded file
            $filePath = UPLOAD_DIR . $filename;
            if (!move_uploaded_file($file['tmp_name'], $filePath)) {
                return [
                    'success' => false,
                    'message' => 'Gagal mengupload file'
                ];
            }
            
            // Insert ke database (pastikan status = 'active')
            $stmt = $this->conn->prepare("
                INSERT INTO documents (title, description, filename, original_filename, file_path, file_size, file_type, 
                                     category_id, shift, page_count, production_date, uploaded_by, target_department, tags, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
            ");
            
            $stmt->execute([
                $title, $description, $filename, $file['name'], $filePath, $file['size'], 
                $extension, $categoryId, $shift, $pageCount, $productionDate, $userId, $targetDepartment, $tags
            ]);
            
            $documentId = $this->conn->lastInsertId();
            
            // Insert tags jika ada
            if (!empty($tags)) {
                $tagArray = explode(',', $tags);
                foreach ($tagArray as $tag) {
                    $tag = trim($tag);
                    if (!empty($tag)) {
                        $stmt = $this->conn->prepare("INSERT INTO document_tags (document_id, tag_name) VALUES (?, ?)");
                        $stmt->execute([$documentId, $tag]);
                    }
                }
            }
            
            // Log upload
            write_log("Document uploaded: {$title} by user ID: {$userId}", 'INFO');
            
            return [
                'success' => true,
                'message' => 'Dokumen berhasil diupload',
                'document_id' => $documentId
            ];
            
        } catch (PDOException $e) {
            write_log("Upload document error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Validasi file upload
     */
    private function validateFile($file) {
        // Check file size
        if ($file['size'] > MAX_FILE_SIZE) {
            return [
                'success' => false,
                'message' => 'Ukuran file terlalu besar. Maksimal ' . format_file_size(MAX_FILE_SIZE)
            ];
        }
        
        // Check file extension
        $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($extension, ALLOWED_EXTENSIONS)) {
            return [
                'success' => false,
                'message' => 'Tipe file tidak diizinkan. Tipe yang diizinkan: ' . implode(', ', ALLOWED_EXTENSIONS)
            ];
        }
        
        // Check upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return [
                'success' => false,
                'message' => 'Error upload file: ' . $file['error']
            ];
        }
        
        return ['success' => true];
    }
    
    /**
     * Get dokumen berdasarkan ID
     */
    public function getDocumentById($id) {
        try {
            $stmt = $this->conn->prepare("
                SELECT d.*, c.name as category_name, u.full_name as uploader_name
                FROM documents d
                LEFT JOIN categories c ON d.category_id = c.id
                LEFT JOIN users u ON d.uploaded_by = u.id
                WHERE d.id = ? AND d.status = 'active'
            ");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            write_log("Get document error: " . $e->getMessage(), 'ERROR');
            return null;
        }
    }
    
    /**
     * Search dokumen
     */
    public function searchDocuments($keyword, $categoryId = null, $shift = null, $pageCount = null, $startDate = null, $endDate = null, $department = null, $page = 1) {
        try {
            $where = "WHERE d.status = 'active'";
            $params = [];
            
            if (!empty($keyword)) {
                $where .= " AND (d.title LIKE ? OR d.description LIKE ? OR d.shift LIKE ?)";
                $searchTerm = "%{$keyword}%";
                $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm]);
            }
            
            if (!empty($categoryId)) {
                $where .= " AND d.category_id = ?";
                $params[] = $categoryId;
            }
            
            if (!empty($shift)) {
                $where .= " AND d.shift = ?";
                $params[] = $shift;
            }
            
            if (!empty($pageCount)) {
                $where .= " AND d.page_count = ?";
                $params[] = $pageCount;
            }
            
            if (!empty($startDate)) {
                $where .= " AND d.production_date >= ?";
                $params[] = $startDate;
            }
            
            if (!empty($endDate)) {
                $where .= " AND d.production_date <= ?";
                $params[] = $endDate;
            }
            
            // Filter by department if specified
            if (!empty($department)) {
                $where .= " AND LOWER(TRIM(d.target_department)) = LOWER(TRIM(?))";
                $params[] = $department;
            }
            
            // Count total records
            $countStmt = $this->conn->prepare("
                SELECT COUNT(*) as total FROM documents d {$where}
            ");
            $countStmt->execute($params);
            $totalRecords = $countStmt->fetch()['total'];
            
            // Calculate pagination
            $offset = ($page - 1) * ITEMS_PER_PAGE;
            $totalPages = ceil($totalRecords / ITEMS_PER_PAGE);
            
            // Get documents (hindari bind LIMIT/OFFSET agar kompatibel di MySQL non-emulated prepares)
            $limitSql = " LIMIT " . (int)ITEMS_PER_PAGE . " OFFSET " . (int)$offset;
            $sql = "
                SELECT d.*, c.name as category_name, c.color as category_color, u.full_name as uploader_name, u.department as uploader_department
                FROM documents d
                LEFT JOIN categories c ON d.category_id = c.id
                LEFT JOIN users u ON d.uploaded_by = u.id
                {$where}
                ORDER BY d.upload_date DESC
            " . $limitSql;
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $documents = $stmt->fetchAll();
            
            return [
                'documents' => $documents,
                'pagination' => [
                    'current_page' => $page,
                    'total_pages' => $totalPages,
                    'total_records' => $totalRecords,
                    'items_per_page' => ITEMS_PER_PAGE
                ]
            ];
            
        } catch (PDOException $e) {
            write_log("Search documents error: " . $e->getMessage(), 'ERROR');
            return [
                'documents' => [],
                'pagination' => [
                    'current_page' => 1,
                    'total_pages' => 1,
                    'total_records' => 0,
                    'items_per_page' => ITEMS_PER_PAGE
                ]
            ];
        }
    }
    
    /**
     * Get dokumen berdasarkan kategori
     */
    public function getDocumentsByCategory($categoryId, $page = 1) {
        return $this->searchDocuments('', $categoryId, null, null, null, null, $page);
    }
    
    /**
     * Get dokumen berdasarkan shift
     */
    public function getDocumentsByShift($shift) {
        try {
            $stmt = $this->conn->prepare("
                SELECT d.*, c.name as category_name, c.color as category_color, u.full_name as uploader_name
                FROM documents d
                LEFT JOIN categories c ON d.category_id = c.id
                LEFT JOIN users u ON d.uploaded_by = u.id
                WHERE d.shift = ? AND d.status = 'active'
                ORDER BY d.upload_date DESC
            ");
            $stmt->execute([$shift]);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            write_log("Get documents by shift error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }
    
    /**
     * Update dokumen
     */
    public function updateDocument($id, $title, $description, $categoryId, $shift, $pageCount, $productionDate, $tags, $userId) {
        try {
            // Check if user can edit
            $document = $this->getDocumentById($id);
            if (!$document) {
                return [
                    'success' => false,
                    'message' => 'Dokumen tidak ditemukan'
                ];
            }
            
            // Update dokumen
            $stmt = $this->conn->prepare("
                UPDATE documents 
                SET title = ?, description = ?, category_id = ?, shift = ?, 
                    page_count = ?, production_date = ?, tags = ?
                WHERE id = ?
            ");
            
            $stmt->execute([
                $title, $description, $categoryId, $shift, $pageCount, 
                $productionDate, $tags, $id
            ]);
            
            // Update tags
            $this->conn->prepare("DELETE FROM document_tags WHERE document_id = ?")->execute([$id]);
            
            if (!empty($tags)) {
                $tagArray = explode(',', $tags);
                foreach ($tagArray as $tag) {
                    $tag = trim($tag);
                    if (!empty($tag)) {
                        $stmt = $this->conn->prepare("INSERT INTO document_tags (document_id, tag_name) VALUES (?, ?)");
                        $stmt->execute([$id, $tag]);
                    }
                }
            }
            
            // Log update
            write_log("Document updated: ID {$id} by user ID: {$userId}", 'INFO');
            
            return [
                'success' => true,
                'message' => 'Dokumen berhasil diupdate'
            ];
            
        } catch (PDOException $e) {
            write_log("Update document error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Delete dokumen (soft delete)
     */
    public function deleteDocument($id, $userId) {
        try {
            $stmt = $this->conn->prepare("UPDATE documents SET status = 'deleted' WHERE id = ?");
            $stmt->execute([$id]);
            
            // Log delete
            write_log("Document deleted: ID {$id} by user ID: {$userId}", 'INFO');
            
            return [
                'success' => true,
                'message' => 'Dokumen berhasil dihapus'
            ];
            
        } catch (PDOException $e) {
            write_log("Delete document error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Download dokumen
     */
    public function downloadDocument($id, $userId) {
        try {
            $document = $this->getDocumentById($id);
            if (!$document) {
                return [
                    'success' => false,
                    'message' => 'Dokumen tidak ditemukan'
                ];
            }
            
            $filePath = $document['file_path'];
            if (!file_exists($filePath)) {
                return [
                    'success' => false,
                    'message' => 'File tidak ditemukan'
                ];
            }
            
            // Log download
            $this->logDocumentAccess($id, $userId, 'download');
            
            return [
                'success' => true,
                'file_path' => $filePath,
                'filename' => $document['original_filename'],
                'file_type' => $document['file_type']
            ];
            
        } catch (Exception $e) {
            write_log("Download document error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Log akses dokumen
     */
    public function logDocumentAccess($documentId, $userId, $action) {
        try {
            // Log ke document_access_log (jika tabel ada)
            try {
                $stmt = $this->conn->prepare("
                    INSERT INTO document_access_log (document_id, user_id, action, ip_address, user_agent)
                    VALUES (?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $documentId, $userId, $action, 
                    $_SERVER['REMOTE_ADDR'] ?? '', 
                    $_SERVER['HTTP_USER_AGENT'] ?? ''
                ]);
            } catch (PDOException $e) {
                // Table mungkin belum ada, skip
            }
            
            // Jika action adalah download, log juga ke download_logs
            if ($action === 'download') {
                try {
                    $stmt = $this->conn->prepare("
                        INSERT INTO download_logs (document_id, user_id, ip_address, user_agent)
                        VALUES (?, ?, ?, ?)
                    ");
                    
                    $stmt->execute([
                        $documentId, 
                        $userId, 
                        $_SERVER['REMOTE_ADDR'] ?? '', 
                        $_SERVER['HTTP_USER_AGENT'] ?? ''
                    ]);
                } catch (PDOException $e) {
                    // Table mungkin belum ada
                    write_log("Log download error (table may not exist): " . $e->getMessage(), 'WARNING');
                }
            }
        } catch (PDOException $e) {
            write_log("Log document access error: " . $e->getMessage(), 'ERROR');
        }
    }
    
    /**
     * Get dokumen statistics
     */
    public function getDocumentStats($department = null) {
        try {
            $stats = [];
            
            // Total dokumen (filter by department if specified)
            $sql = "SELECT COUNT(*) as total FROM documents WHERE status = 'active'";
            $params = [];
            
            if ($department) {
                $sql .= " AND LOWER(TRIM(target_department)) = LOWER(TRIM(?))";
                $params[] = $department;
            }
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $stats['total_documents'] = $stmt->fetch()['total'];
            
            // Dokumen per kategori
            $stmt = $this->conn->prepare("
                SELECT c.name, COUNT(d.id) as count
                FROM categories c
                LEFT JOIN documents d ON c.id = d.category_id AND d.status = 'active'
                GROUP BY c.id, c.name
                ORDER BY count DESC
            ");
            $stmt->execute();
            $stats['by_category'] = $stmt->fetchAll();
            
            // Dokumen per bulan (tahun ini)
            $stmt = $this->conn->prepare("
                SELECT DATE_FORMAT(upload_date, '%Y-%m') as month, COUNT(*) as count
                FROM documents
                WHERE status = 'active' AND YEAR(upload_date) = YEAR(CURRENT_DATE())
                GROUP BY DATE_FORMAT(upload_date, '%Y-%m')
                ORDER BY month DESC
            ");
            $stmt->execute();
            $stats['by_month'] = $stmt->fetchAll();
            
            return $stats;
            
        } catch (PDOException $e) {
            write_log("Get document stats error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }

    /**
     * Get dokumen berdasarkan department (dengan pagination)
     */
    public function getDocumentsByDepartment($department, $page = 1, $keyword = '') {
        try {
            $offset = ($page - 1) * ITEMS_PER_PAGE;
            
            // Build where clause
            $where = "WHERE d.status = 'active'";
            $params = [];

            // If department specified (non-empty), filter by department
            if (!empty($department)) {
                $where .= " AND LOWER(TRIM(d.target_department)) = LOWER(TRIM(?))";
                $params[] = $department;
            }
            
            // Add keyword search if provided
            if (!empty($keyword)) {
                $where .= " AND (d.title LIKE ? OR d.description LIKE ? OR d.tags LIKE ?)";
                $searchTerm = "%{$keyword}%";
                $params[] = $searchTerm;
                $params[] = $searchTerm;
                $params[] = $searchTerm;
            }
            
            // Get total count
            $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM documents d {$where}");
            $stmt->execute($params);
            $totalRecords = $stmt->fetch()['total'];
            $totalPages = ceil($totalRecords / ITEMS_PER_PAGE);
            
            // Get documents (hindari bind LIMIT/OFFSET)
            $limitSql = " LIMIT " . (int)ITEMS_PER_PAGE . " OFFSET " . (int)$offset;
            $sql = "
                SELECT d.*, c.name as category_name, c.color as category_color, u.full_name as uploader_name, u.department as uploader_department
                FROM documents d
                LEFT JOIN categories c ON d.category_id = c.id
                LEFT JOIN users u ON d.uploaded_by = u.id
                {$where}
                ORDER BY d.upload_date DESC
            " . $limitSql;
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $documents = $stmt->fetchAll();
            
            return [
                'documents' => $documents,
                'pagination' => [
                    'current_page' => $page,
                    'total_pages' => $totalPages,
                    'total_records' => $totalRecords,
                    'items_per_page' => ITEMS_PER_PAGE
                ]
            ];
            
        } catch (PDOException $e) {
            write_log("Get documents by department error: " . $e->getMessage(), 'ERROR');
            return [
                'documents' => [],
                'pagination' => [
                    'current_page' => 1,
                    'total_pages' => 1,
                    'total_records' => 0,
                    'items_per_page' => ITEMS_PER_PAGE
                ]
            ];
        }
    }

    /**
     * Get list semua department yang ada di dokumen
     */
    public function getAllDepartments() {
        try {
            $stmt = $this->conn->prepare("
                SELECT DISTINCT target_department 
                FROM documents 
                WHERE target_department IS NOT NULL AND status = 'active'
                ORDER BY target_department ASC
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            write_log("Get all departments error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }

    /**
     * Get list department dari table users
     */
    public function getActiveDepartments() {
        try {
            $stmt = $this->conn->prepare("
                SELECT DISTINCT department 
                FROM users 
                WHERE department IS NOT NULL AND department != '' AND is_active = 1
                ORDER BY department ASC
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            write_log("Get active departments error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }
}
?>
