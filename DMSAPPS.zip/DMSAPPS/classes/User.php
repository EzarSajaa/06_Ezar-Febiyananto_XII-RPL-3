<?php
require_once 'config/config.php';
require_once 'config/database.php';

class User {
    private $conn;

    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }

    private function requireAdmin() {
        if (!isset($_SESSION['user_role']) || !in_array($_SESSION['user_role'], ['admin', 'superadmin'])) {
            return [ 'ok' => false, 'response' => [ 'success' => false, 'message' => 'Akses ditolak' ] ];
        }
        return [ 'ok' => true ];
    }

    public function getAll() {
        $guard = $this->requireAdmin();
        if (!$guard['ok']) { return []; }

        try {
            $stmt = $this->conn->prepare("SELECT id, username, full_name, email, role, department, is_active, created_at FROM users ORDER BY created_at DESC");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            write_log("User::getAll error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }

    public function getById($id) {
        $guard = $this->requireAdmin();
        if (!$guard['ok']) { return null; }

        try {
            $stmt = $this->conn->prepare("SELECT id, username, full_name, email, role, department, is_active, created_at FROM users WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            write_log("User::getById error: " . $e->getMessage(), 'ERROR');
            return null;
        }
    }

    public function create($data) {
        $guard = $this->requireAdmin();
        if (!$guard['ok']) { return $guard['response']; }

        $username = sanitize_input($data['username'] ?? '');
        $fullName = sanitize_input($data['full_name'] ?? '');
        $email = sanitize_input($data['email'] ?? '');
        $role = sanitize_input($data['role'] ?? 'user');
        $department = sanitize_input($data['department'] ?? '');
        $password = $data['password'] ?? '';

        if (empty($username) || empty($fullName) || empty($email) || empty($password)) {
            return [ 'success' => false, 'message' => 'Semua field wajib diisi' ];
        }
        if (!is_valid_email($email)) {
            return [ 'success' => false, 'message' => 'Email tidak valid' ];
        }
        if (strlen($password) < PASSWORD_MIN_LENGTH) {
            return [ 'success' => false, 'message' => 'Password minimal ' . PASSWORD_MIN_LENGTH . ' karakter' ];
        }

        try {
            // Unique checks
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$username]);
            if ($stmt->fetch()) {
                return [ 'success' => false, 'message' => 'Username sudah ada' ];
            }
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                return [ 'success' => false, 'message' => 'Email sudah ada' ];
            }

            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("INSERT INTO users (username, password, full_name, email, role, department, is_active) VALUES (?, ?, ?, ?, ?, ?, 1)");
            $stmt->execute([$username, $hashed, $fullName, $email, $role, $department]);
            $id = $this->conn->lastInsertId();
            write_log("Admin membuat user: {$username}", 'INFO');
            return [ 'success' => true, 'message' => 'User berhasil dibuat', 'user_id' => $id ];
        } catch (PDOException $e) {
            write_log("User::create error: " . $e->getMessage(), 'ERROR');
            return [ 'success' => false, 'message' => 'Terjadi kesalahan sistem' ];
        }
    }

    public function update($id, $data) {
        $guard = $this->requireAdmin();
        if (!$guard['ok']) { return $guard['response']; }

        $fullName = sanitize_input($data['full_name'] ?? '');
        $email = sanitize_input($data['email'] ?? '');
        $role = sanitize_input($data['role'] ?? 'user');
        $department = sanitize_input($data['department'] ?? '');
        $isActive = isset($data['is_active']) ? (int)!!$data['is_active'] : null;

        if (empty($fullName) || empty($email)) {
            return [ 'success' => false, 'message' => 'Nama dan email wajib diisi' ];
        }
        if (!is_valid_email($email)) {
            return [ 'success' => false, 'message' => 'Email tidak valid' ];
        }

        try {
            // Ensure email unique (excluding current id)
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ? AND id <> ?");
            $stmt->execute([$email, $id]);
            if ($stmt->fetch()) {
                return [ 'success' => false, 'message' => 'Email sudah digunakan' ];
            }

            $fields = [ 'full_name' => $fullName, 'email' => $email, 'role' => $role, 'department' => $department ];
            if ($isActive !== null) { $fields['is_active'] = $isActive; }

            $setParts = [];
            $values = [];
            foreach ($fields as $col => $val) {
                $setParts[] = "$col = ?";
                $values[] = $val;
            }
            $values[] = $id;
            $sql = "UPDATE users SET " . implode(', ', $setParts) . " WHERE id = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($values);

            write_log("Admin mengubah user ID {$id}", 'INFO');
            return [ 'success' => true, 'message' => 'User berhasil diperbarui' ];
        } catch (PDOException $e) {
            write_log("User::update error: " . $e->getMessage(), 'ERROR');
            return [ 'success' => false, 'message' => 'Terjadi kesalahan sistem' ];
        }
    }

    public function updatePassword($id, $newPassword) {
        $guard = $this->requireAdmin();
        if (!$guard['ok']) { return $guard['response']; }
        if (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
            return [ 'success' => false, 'message' => 'Password minimal ' . PASSWORD_MIN_LENGTH . ' karakter' ];
        }
        try {
            $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed, $id]);
            write_log("Admin reset password user ID {$id}", 'INFO');
            return [ 'success' => true, 'message' => 'Password berhasil direset' ];
        } catch (PDOException $e) {
            write_log("User::updatePassword error: " . $e->getMessage(), 'ERROR');
            return [ 'success' => false, 'message' => 'Terjadi kesalahan sistem' ];
        }
    }

    public function delete($id) {
        $guard = $this->requireAdmin();
        if (!$guard['ok']) { return $guard['response']; }

        try {
            $stmt = $this->conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            write_log("Admin menghapus user ID {$id}", 'INFO');
            return [ 'success' => true, 'message' => 'User berhasil dihapus' ];
        } catch (PDOException $e) {
            write_log("User::delete error: " . $e->getMessage(), 'ERROR');
            return [ 'success' => false, 'message' => 'Terjadi kesalahan sistem' ];
        }
    }

    /**
     * Update profil user sendiri (tanpa perlu admin)
     */
    public function updateOwnProfile($userId, $data) {
        $fullName = sanitize_input($data['full_name'] ?? '');
        $email = sanitize_input($data['email'] ?? '');
        $department = sanitize_input($data['department'] ?? '');

        if (empty($fullName) || empty($email)) {
            return [ 'success' => false, 'message' => 'Nama dan email wajib diisi' ];
        }
        if (!is_valid_email($email)) {
            return [ 'success' => false, 'message' => 'Email tidak valid' ];
        }

        try {
            // Ensure email unique (excluding current user)
            $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ? AND id <> ?");
            $stmt->execute([$email, $userId]);
            if ($stmt->fetch()) {
                return [ 'success' => false, 'message' => 'Email sudah digunakan oleh user lain' ];
            }

            $stmt = $this->conn->prepare("UPDATE users SET full_name = ?, email = ?, department = ? WHERE id = ?");
            $stmt->execute([$fullName, $email, $department, $userId]);

            // Update session data using the same keys expected by Auth class
            $_SESSION['full_name'] = $fullName;
            $_SESSION['email'] = $email;
            $_SESSION['department'] = $department;
            // Also keep legacy keys (some pages used different session keys previously)
            $_SESSION['user_full_name'] = $fullName;
            $_SESSION['user_email'] = $email;
            $_SESSION['user_department'] = $department;

            write_log("User ID {$userId} mengubah profil", 'INFO');
            return [ 'success' => true, 'message' => 'Profil berhasil diperbarui' ];
        } catch (PDOException $e) {
            write_log("User::updateOwnProfile error: " . $e->getMessage(), 'ERROR');
            return [ 'success' => false, 'message' => 'Terjadi kesalahan sistem' ];
        }
    }

    /**
     * Update password user sendiri (tanpa perlu admin)
     */
    public function updateOwnPassword($userId, $currentPassword, $newPassword) {
        if (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
            return [ 'success' => false, 'message' => 'Password baru minimal ' . PASSWORD_MIN_LENGTH . ' karakter' ];
        }

        try {
            // Verify current password
            $stmt = $this->conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($currentPassword, $user['password'])) {
                return [ 'success' => false, 'message' => 'Password saat ini salah' ];
            }

            // Update to new password
            $hashed = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashed, $userId]);

            write_log("User ID {$userId} mengganti password", 'INFO');
            return [ 'success' => true, 'message' => 'Password berhasil diubah' ];
        } catch (PDOException $e) {
            write_log("User::updateOwnPassword error: " . $e->getMessage(), 'ERROR');
            return [ 'success' => false, 'message' => 'Terjadi kesalahan sistem' ];
        }
    }

    /**
     * Get user statistics
     */
    public function getUserStats($userId) {
        try {
            $stats = [];
            
            // Total documents uploaded by user
            $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM documents WHERE uploaded_by = ? AND status = 'active'");
            $stmt->execute([$userId]);
            $stats['total_documents'] = $stmt->fetch()['count'];
            
            // Total downloads by user (if tracking downloads)
            $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM download_logs WHERE user_id = ?");
            $stmt->execute([$userId]);
            $stats['total_downloads'] = $stmt->fetch()['count'] ?? 0;
            
            // Recent uploads
            $stmt = $this->conn->prepare("
                SELECT d.*, c.name as category_name, c.color as category_color
                FROM documents d
                LEFT JOIN categories c ON d.category_id = c.id
                WHERE d.uploaded_by = ? AND d.status = 'active'
                ORDER BY d.upload_date DESC
                LIMIT 5
            ");
            $stmt->execute([$userId]);
            $stats['recent_uploads'] = $stmt->fetchAll();
            
            return $stats;
        } catch (PDOException $e) {
            write_log("User::getUserStats error: " . $e->getMessage(), 'ERROR');
            return [
                'total_documents' => 0,
                'total_downloads' => 0,
                'recent_uploads' => []
            ];
        }
    }

    /**
     * Get full user data by ID (including created_at)
     */
    public function getFullUserData($userId) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            write_log("User::getFullUserData error: " . $e->getMessage(), 'ERROR');
            return null;
        }
    }

    /**
     * Get total active users count
     */
    public function getTotalActiveUsers() {
        try {
            $stmt = $this->conn->prepare("SELECT COUNT(*) as total FROM users WHERE is_active = 1");
            $stmt->execute();
            $result = $stmt->fetch();
            return $result['total'] ?? 0;
        } catch (PDOException $e) {
            write_log("User::getTotalActiveUsers error: " . $e->getMessage(), 'ERROR');
            return 0;
        }
    }
}
?>


