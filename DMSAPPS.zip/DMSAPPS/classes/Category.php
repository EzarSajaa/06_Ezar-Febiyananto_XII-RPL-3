<?php
require_once 'config/config.php';
require_once 'config/database.php';

class Category {
    private $conn;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    /**
     * Get semua kategori
     */
    public function getAllCategories() {
        try {
            $stmt = $this->conn->prepare("
                SELECT c.*, COUNT(d.id) as document_count
                FROM categories c
                LEFT JOIN documents d ON c.id = d.category_id AND d.status = 'active'
                GROUP BY c.id, c.name, c.description, c.color, c.created_at, c.updated_at
                ORDER BY c.name ASC
            ");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            write_log("Get categories error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }
    
    /**
     * Get kategori berdasarkan ID
     */
    public function getCategoryById($id) {
        try {
            $stmt = $this->conn->prepare("SELECT * FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            return $stmt->fetch();
        } catch (PDOException $e) {
            write_log("Get category error: " . $e->getMessage(), 'ERROR');
            return null;
        }
    }
    
    /**
     * Create kategori baru
     */
    public function createCategory($name, $description, $color) {
        try {
            // Check if name exists
            $stmt = $this->conn->prepare("SELECT id FROM categories WHERE name = ?");
            $stmt->execute([$name]);
            if ($stmt->fetch()) {
                return [
                    'success' => false,
                    'message' => 'Nama kategori sudah ada'
                ];
            }
            
            // Insert kategori
            $stmt = $this->conn->prepare("INSERT INTO categories (name, description, color) VALUES (?, ?, ?)");
            $stmt->execute([$name, $description, $color]);
            
            $categoryId = $this->conn->lastInsertId();
            write_log("Category created: {$name}", 'INFO');
            
            return [
                'success' => true,
                'message' => 'Kategori berhasil dibuat',
                'category_id' => $categoryId
            ];
            
        } catch (PDOException $e) {
            write_log("Create category error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Update kategori
     */
    public function updateCategory($id, $name, $description, $color) {
        try {
            // Check if name exists (excluding current category)
            $stmt = $this->conn->prepare("SELECT id FROM categories WHERE name = ? AND id != ?");
            $stmt->execute([$name, $id]);
            if ($stmt->fetch()) {
                return [
                    'success' => false,
                    'message' => 'Nama kategori sudah ada'
                ];
            }
            
            // Update kategori
            $stmt = $this->conn->prepare("UPDATE categories SET name = ?, description = ?, color = ? WHERE id = ?");
            $stmt->execute([$name, $description, $color, $id]);
            
            write_log("Category updated: ID {$id}", 'INFO');
            
            return [
                'success' => true,
                'message' => 'Kategori berhasil diupdate'
            ];
            
        } catch (PDOException $e) {
            write_log("Update category error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Delete kategori
     */
    public function deleteCategory($id) {
        try {
            // Check if category has documents
            $stmt = $this->conn->prepare("SELECT COUNT(*) as count FROM documents WHERE category_id = ? AND status = 'active'");
            $stmt->execute([$id]);
            $documentCount = $stmt->fetch()['count'];
            
            if ($documentCount > 0) {
                return [
                    'success' => false,
                    'message' => "Tidak dapat menghapus kategori. Masih ada {$documentCount} dokumen yang menggunakan kategori ini."
                ];
            }
            
            // Delete kategori
            $stmt = $this->conn->prepare("DELETE FROM categories WHERE id = ?");
            $stmt->execute([$id]);
            
            write_log("Category deleted: ID {$id}", 'INFO');
            
            return [
                'success' => true,
                'message' => 'Kategori berhasil dihapus'
            ];
            
        } catch (PDOException $e) {
            write_log("Delete category error: " . $e->getMessage(), 'ERROR');
            return [
                'success' => false,
                'message' => 'Terjadi kesalahan sistem'
            ];
        }
    }
    
    /**
     * Get kategori untuk dropdown
     */
    public function getCategoriesForDropdown() {
        try {
            $stmt = $this->conn->prepare("SELECT id, name FROM categories ORDER BY name ASC");
            $stmt->execute();
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            write_log("Get categories dropdown error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }
    
    /**
     * Get kategori statistics
     */
    public function getCategoryStats($department = null) {
        try {
            $params = [];
            $sql = "
                SELECT c.name, c.color, COUNT(d.id) as document_count
                FROM categories c
                LEFT JOIN documents d ON c.id = d.category_id AND d.status = 'active'
            ";
            
            if ($department) {
                $sql .= " AND LOWER(TRIM(d.target_department)) = LOWER(TRIM(?))";
                $params[] = $department;
            }
            
            $sql .= " GROUP BY c.id, c.name, c.color ORDER BY document_count DESC";
            
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            write_log("Get category stats error: " . $e->getMessage(), 'ERROR');
            return [];
        }
    }
}
?>
