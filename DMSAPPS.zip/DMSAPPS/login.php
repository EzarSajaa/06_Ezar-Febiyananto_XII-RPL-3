<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';

// Redirect if already logged in
if (is_logged_in()) {
    redirect('index.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize_input($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        $error = 'Username dan password harus diisi';
    } else {
        $auth = new Auth();
        $result = $auth->login($username, $password);
        
        if ($result['success']) {
            redirect('index.php');
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-container {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
            border: 1px solid #e9ecef;
        }
        .login-header {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            color: white;
            padding: 1rem;
            text-align: center;
        }
        .login-body {
            padding: 2rem;
        }
        .form-control {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            padding: 12px 15px;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #495057;
            box-shadow: 0 0 0 0.2rem rgba(73, 80, 87, 0.15);
        }
        .btn-login {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            border: none;
            border-radius: 10px;
            padding: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(73, 80, 87, 0.3);
        }
        .alert {
            border-radius: 10px;
        }
            .login-logo {
                width: 150px;
                height: auto;
                display: inline-block;
            }
            @media (max-width: 768px) {
                .login-logo { width: 140px; }
            }
            @media (max-width: 480px) {
                .login-logo { width: 110px; }
            }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="login-container">
                    <div class="login-header">
                        <img src="assets/images/tacipart2.png" alt="TACI Logo" class="login-logo mb-3">
                        <h2><?php echo APP_NAME; ?></h2>
                        <p class="mb-0">Document Management Apps</p>
                    </div>
                    
                    <div class="login-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <i class="fas fa-check-circle me-2"></i>
                                <?php echo $success; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="username" class="form-label">
                                    <i class="fas fa-user me-2"></i>Username
                                </label>
                                <input type="text" class="form-control" id="username" name="username" 
                                       value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" 
                                       required autofocus>
                            </div>
                            
                            <div class="mb-4">
                                <label for="password" class="form-label">
                                    <i class="fas fa-lock me-2"></i>Password
                                </label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            
                            <button type="submit" class="btn btn-primary btn-login w-100">
                                <i class="fas fa-sign-in-alt me-2"></i>Login
                            </button>
                        </form>
                        

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Jika ada alert error dari server, tutup otomatis dan reset form (hapus password) setelah beberapa detik
        document.addEventListener('DOMContentLoaded', function() {
            var alertEl = document.querySelector('.alert.alert-danger');
            if (!alertEl) return;

            // Delay sebelum menutup alert dan mereset form (ms)
            var AUTO_CLOSE_MS = 3000;

            setTimeout(function() {
                try {
                    // Jika Bootstrap tersedia, gunakan API untuk menutup alert dengan animasi
                    if (window.bootstrap && bootstrap.Alert) {
                        var bsAlert = new bootstrap.Alert(alertEl);
                        bsAlert.close();
                    } else {
                        // Fallback: hapus elemen
                        alertEl.remove();
                    }
                } catch (e) {
                    alertEl.remove();
                }

                // Reset hanya field password supaya user tidak perlu ulang mengetik username
                var form = document.querySelector('form');
                if (form) {
                    var pwd = form.querySelector('input[name="password"]');
                    if (pwd) pwd.value = '';
                    var user = form.querySelector('input[name="username"]');
                    if (user) user.focus();
                }
            }, AUTO_CLOSE_MS);
        });
    </script>
</body>
</html>
