<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'config/database.php';

// Require login and admin role
$auth = new Auth();
if (!$auth->isLoggedIn() || !($auth->isAdmin() || $auth->isSuperAdmin())) {
    redirect('login.php');
}

// Ensure backup directory exists
if (!is_dir(BACKUP_DIR)) {
    mkdir(BACKUP_DIR, 0755, true);
}

// Build filenames
$timestamp = date('Ymd_His');
$dbSqlName = "db_backup_{$timestamp}.sql";
$zipName = "backup_{$timestamp}.zip";
$dbSqlPath = rtrim(BACKUP_DIR, '/\\') . DIRECTORY_SEPARATOR . $dbSqlName;
$zipPath = rtrim(BACKUP_DIR, '/\\') . DIRECTORY_SEPARATOR . $zipName;

// Create database dump
$database = new Database();
$host = $database->getHost();
$dbName = $database->getDatabaseName();
$dbUser = $database->getUsername();
$dbPass = $database->getPassword();

function try_mysqldump($host, $dbName, $dbUser, $dbPass, $outputFile) {
    $cmd = "mysqldump --host=" . escapeshellarg($host) .
           " --user=" . escapeshellarg($dbUser) .
           (strlen($dbPass) ? (" --password=" . escapeshellarg($dbPass)) : '') .
           " --routines --events --triggers --single-transaction --databases " . escapeshellarg($dbName) .
           " > " . escapeshellarg($outputFile);
    $result = null;
    $output = [];
    @exec($cmd, $output, $result);
    return is_int($result) ? $result === 0 : false;
}

function pdo_dump($host, $dbName, $dbUser, $dbPass, $outputFile) {
    $dsn = "mysql:host={$host};dbname={$dbName};charset=utf8";
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $fh = fopen($outputFile, 'w');
    if (!$fh) { throw new Exception('Tidak dapat menulis file SQL'); }

    fwrite($fh, "-- Simple SQL dump generated at " . date('Y-m-d H:i:s') . "\n");
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=0;\n\n");

    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $createStmt = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch();
        $createSql = $createStmt['Create Table'] ?? $createStmt[1];
        fwrite($fh, "DROP TABLE IF EXISTS `{$table}`;\n");
        fwrite($fh, $createSql . ";\n\n");

        $rows = $pdo->query("SELECT * FROM `{$table}`");
        while ($row = $rows->fetch(PDO::FETCH_ASSOC)) {
            $columns = array_map(function($c){ return "`" . str_replace("`", "``", $c) . "`"; }, array_keys($row));
            $values = array_map(function($v) use ($pdo) {
                if (is_null($v)) return 'NULL';
                return $pdo->quote($v);
            }, array_values($row));
            $insert = "INSERT INTO `{$table}` (" . implode(',', $columns) . ") VALUES (" . implode(',', $values) . ");\n";
            fwrite($fh, $insert);
        }
        fwrite($fh, "\n");
    }

    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
}

$dumpOk = false;
try {
    // Prefer mysqldump if available
    $dumpOk = try_mysqldump($host, $dbName, $dbUser, $dbPass, $dbSqlPath);
    if (!$dumpOk) {
        pdo_dump($host, $dbName, $dbUser, $dbPass, $dbSqlPath);
        $dumpOk = true;
    }
} catch (Throwable $e) {
    write_log('Backup DB dump error: ' . $e->getMessage(), 'ERROR');
}

if (!$dumpOk || !file_exists($dbSqlPath)) {
    write_log('Backup failed: DB dump not created', 'ERROR');
    header('HTTP/1.1 500 Internal Server Error');
    echo 'Gagal membuat backup database';
    exit;
}

// Create ZIP with uploads and SQL
$zip = new ZipArchive();
if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== TRUE) {
    @unlink($dbSqlPath);
    write_log('Backup failed: cannot create ZIP', 'ERROR');
    header('HTTP/1.1 500 Internal Server Error');
    echo 'Gagal membuat file ZIP backup';
    exit;
}

// Add SQL dump
$zip->addFile($dbSqlPath, $dbSqlName);

// Add uploads directory recursively (if exists)
$uploadsDir = rtrim(UPLOAD_DIR, '/\\');
if (is_dir($uploadsDir)) {
    $dirIter = new RecursiveDirectoryIterator($uploadsDir, FilesystemIterator::SKIP_DOTS);
    $iter = new RecursiveIteratorIterator($dirIter, RecursiveIteratorIterator::SELF_FIRST);
    foreach ($iter as $fileInfo) {
        $realPath = $fileInfo->getPathname();
        $localPath = substr($realPath, strlen($uploadsDir) + 1);
        $zipPathLocal = 'uploads/' . str_replace('\\', '/', $localPath);
        if ($fileInfo->isDir()) {
            $zip->addEmptyDir($zipPathLocal);
        } else {
            $zip->addFile($realPath, $zipPathLocal);
        }
    }
}

$zip->close();

// Remove temporary SQL dump
@unlink($dbSqlPath);

// Retention: keep only latest MAX_BACKUP_FILES
$files = glob(rtrim(BACKUP_DIR, '/\\') . DIRECTORY_SEPARATOR . 'backup_*.zip');
if (is_array($files)) {
    rsort($files, SORT_STRING); // filenames include timestamp
    $toDelete = array_slice($files, MAX_BACKUP_FILES);
    foreach ($toDelete as $old) {
        @unlink($old);
    }
}

write_log('Backup created: ' . $zipName, 'INFO');

// Stream the ZIP for download
header('Content-Type: application/zip');
header('Content-Disposition: attachment; filename="' . $zipName . '"');
header('Content-Length: ' . filesize($zipPath));
header('Cache-Control: no-store');
readfile($zipPath);
exit;
?>
