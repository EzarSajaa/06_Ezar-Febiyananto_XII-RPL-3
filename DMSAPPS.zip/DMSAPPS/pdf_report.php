<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'config/database.php';

// Check if user is logged in and is admin
$auth = new Auth();
if (!$auth->isLoggedIn() || !($auth->isAdmin() || $auth->isSuperAdmin())) {
    die('Access denied');
}

$currentUser = $auth->getCurrentUser();
$db = new Database();
$conn = $db->getConnection();

$reportType = sanitize_input($_GET['type'] ?? 'incoming');
$date = sanitize_input($_GET['date'] ?? '');

// Department handling: only trusted if superadmin
$requestedDept = sanitize_input($_GET['department'] ?? '');
if ($auth->isSuperAdmin()) {
    if (empty($requestedDept) || $requestedDept === 'all') {
        $dept = null; // semua
    } else {
        $dept = $requestedDept;
    }
} else {
    $dept = $currentUser['department'] ?? null;
}
$params = [];
$whereClause = "";

if ($reportType === 'outgoing') {
    $sql = "
        SELECT dl.id, dl.download_date as activity_date,
               d.title, d.original_filename, u.full_name as user_name,
               u.department as user_department
        FROM download_logs dl
        INNER JOIN documents d ON d.id = dl.document_id
        INNER JOIN users u ON u.id = dl.user_id
        WHERE 1 = 1
    ";
    if (!empty($dept)) {
        $sql .= " AND LOWER(TRIM(d.target_department)) = LOWER(TRIM(?))";
        $params[] = $dept;
    }
    if (!empty($date)) {
        $whereClause = " AND DATE(dl.download_date) = ?";
        $params[] = $date;
    }
    $sql .= $whereClause . " ORDER BY dl.download_date DESC";
    $title = 'Laporan Dokumen Keluar (Download)';
} else {
    $sql = "
        SELECT d.id, d.upload_date as activity_date,
               d.title, d.original_filename, u.full_name as user_name,
               u.department as user_department
        FROM documents d
        INNER JOIN users u ON u.id = d.uploaded_by
        WHERE d.status = 'active'
    ";
    if (!empty($dept)) {
        $sql .= " AND LOWER(TRIM(d.target_department)) = LOWER(TRIM(?))";
        $params[] = $dept;
    }
    if (!empty($date)) {
        $whereClause = " AND DATE(d.upload_date) = ?";
        $params[] = $date;
    }
    $sql .= $whereClause . " ORDER BY d.upload_date DESC";
    $title = 'Laporan Dokumen Masuk (Upload)';
}

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$dateText = !empty($date) ? date('d/m/Y', strtotime($date)) : 'Semua Tanggal';
$totalData = count($rows);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title); ?></title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
        }
        
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }
        
        /* Kop surat */
        .header {
            display: flex;
            align-items: center;
            justify-content: center; /* center the kop after removing right block */
            gap: 20px;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #333;
        }

        .kop-left {
            width: 18%;
            flex: 0 0 18%;
        }

        .kop-left img {
            max-width: 100%;
            height: auto;
            display: block;
        }

        .kop-center {
            flex: 1 1 auto;
            text-align: center;
            /* geser sedikit ke kiri agar terpusat visual terhadap halaman */
            transform: translateX(-18px);
        }

        @media (max-width: 768px) {
            .kop-center { transform: translateX(-12px); }
        }

        @media (max-width: 480px) {
            .kop-center { transform: translateX(-8px); }
        }
        

        .kop-center .org-name {
            margin: 0;
            color: #333;
            font-size: 18px;
            font-weight: 700;
        }

        .kop-center .org-sub {
            margin: 4px 0 0 0;
            color: #333;
            font-size: 13px;
            font-weight: 600;
        }

        .kop-center .org-address {
            margin: 6px 0 0 0;
            color: #333;
            font-size: 11px;
            font-weight: normal;
        }

        /* .kop-right removed */
        
        .info {
            margin-bottom: 25px;
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #dee2e6;
        }
        
        .info p {
            margin: 5px 0;
            font-weight: 500;
        }
        
        .info strong {
            color: #495057;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 11px;
        }
        
        th, td {
            border: 1px solid #333;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        
        th {
            background-color: #f5f5f5;
            font-weight: bold;
            color: #333;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        .no-data {
            text-align: center;
            padding: 30px;
            color: #666;
            font-style: italic;
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 5px;
        }
        
        /* footer removed as requested */

        /* Signature layout */
        .signature {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin-top: 20px;
            align-items: flex-end; /* ratakan garis tanda tangan di semua kolom */
        }

        .sig-block {
            width: 32%;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            font-size: 12px;
            color: #333;
        }

        .sig-date {
            width: 100%;
            text-align: center; /* pusatkan supaya sejajar dengan jabatan di bawahnya */
            font-size: 12px;
            color: #333;
            margin-bottom: 4px;
            height: 18px; /* reserve space so left/right align */
        }

        .sig-role {
            font-size: 12px;
            margin-bottom: 6px;
            color: #333;
        }

        .sig-space {
            height: 56px; /* space for handwritten signature */
        }

        .sig-name {
            font-weight: bold;
            margin-bottom: 6px;
        }

        .sig-line {
            width: 70%;
            border-top: 1px solid #333;
            margin-bottom: 6px;
            height: 1px;
        }

        .sig-label {
            font-size: 12px;
            margin-top: 6px;
        }
        
        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #dc3545;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1000;
            font-size: 14px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .print-btn:hover {
            background: #c82333;
        }
        
        .date-col {
            width: 15%;
            white-space: nowrap;
        }
        
        .title-col {
            width: 30%;
        }
        
        .file-col {
            width: 25%;
        }
        
        .user-col {
            width: 15%;
        }
        
        .dept-col {
            width: 15%;
        }
    </style>
</head>
<body>
    <button class="print-btn no-print" onclick="window.print()">
        🖨️ Print PDF
    </button>
    
    <div class="header">
        <div class="kop-left">
            <?php if (file_exists('assets/images/tacipart2.png')): ?>
                <img src="assets/images/taci.png" alt="Logo">
            <?php else: ?>
                <img src="assets/images/logo.png" alt="Logo">
            <?php endif; ?>
        </div>

        <div class="kop-center">
            <p class="org-name">PT. TD AUTOMOTIVE COMPRESSOR INDONESIA</p>
            <p class="org-sub"><?php echo htmlspecialchars(APP_NAME); ?> - Document Management Apps</p>
            <p class="org-address">Jl. Slayer No.3,Cikarang barat,cikedokan, Jawa barat — Telp: (021) 0000 0000 — Email: info@taci.co.id
        </div>

        <!-- kop-right (report title/date) removed as requested -->
    </div>
    
    <div class="info">
        <p><strong>Tanggal Laporan:</strong> <?php echo $dateText; ?></p>
        <p><strong>Total Data:</strong> <?php echo $totalData; ?> dokumen</p>
        <p><strong>Dibuat pada:</strong> <?php echo date('d/m/Y H:i'); ?></p>
        <p><strong>Dibuat oleh:</strong> <?php echo htmlspecialchars($currentUser['full_name']); ?></p>
    </div>
    
    <?php if (empty($rows)): ?>
        <div class="no-data">
            <h3>Tidak ada data yang tersedia</h3>
            <p>Tidak ada data <?php echo $reportType === 'outgoing' ? 'download' : 'upload'; ?> 
               <?php if (!empty($date)): ?>
                   untuk tanggal <?php echo date('d/m/Y', strtotime($date)); ?>
               <?php endif; ?>
            </p>
        </div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th class="date-col">Tanggal/Waktu</th>
                    <th class="title-col">Judul Dokumen</th>
                    <th class="file-col">Nama File</th>
                    <th class="user-col">User</th>
                    <th class="dept-col">Department</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td class="date-col"><?php echo date('d/m/Y H:i', strtotime($r['activity_date'])); ?></td>
                        <td class="title-col"><?php echo htmlspecialchars($r['title']); ?></td>
                        <td class="file-col"><?php echo htmlspecialchars($r['original_filename']); ?></td>
                        <td class="user-col"><?php echo htmlspecialchars($r['user_name']); ?></td>
                        <td class="dept-col"><?php echo htmlspecialchars($r['user_department']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    
    <!-- Signature area -->
    
    <!-- Tanggal cetak (hari, tanggal bulan tahun) - tampil di kanan sebelum tanda tangan -->
    <?php
        $hariNames = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
        $bulanNames = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
        $w = date('w');
        $hariText = $hariNames[$w];
        $tanggalNum = date('j');
        $bulanText = $bulanNames[intval(date('n')) - 1];
        $tahunNum = date('Y');
        $printedDateText = $hariText . ', ' . $tanggalNum . ' ' . $bulanText . ' ' . $tahunNum;
    ?>

    <!-- Signature area (left block removed as requested) -->
    <div class="signature" style="margin-top:40px;">

        <!-- Left signature block (no date shown but placeholder kept for alignment) -->
        <div class="sig-block">
            <div class="sig-date">&nbsp;</div>
            <div class="sig-role">Pembimbing Industri</div>
            <div class="sig-space"></div>
            <div class="sig-name">Liayani</div>
            <div class="sig-line"></div>
        </div>

        <!-- Right signature block (date above role) -->
        <div class="sig-block">
            <div class="sig-date"><?php echo htmlspecialchars($printedDateText); ?></div>
            <div class="sig-role">Asistent Manager</div>
            <div class="sig-space"></div>
            <div class="sig-name">Eko Pramono</div>
            <div class="sig-line"></div>
        </div>

    </div>
    
    <script>
        // Auto print when loaded
        window.onload = function() {
            setTimeout(function() {
                window.print();
            }, 1000);
        };
    </script>
</body>
</html>
