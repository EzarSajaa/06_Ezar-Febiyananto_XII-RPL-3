<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/Document.php';
require_once 'classes/Category.php';

// Check login
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

$currentUser = $auth->getCurrentUser();
$document = new Document();
$category = new Category();

// Get filter parameters
$page = (int)($_GET['page'] ?? 1);
$keyword = sanitize_input($_GET['keyword'] ?? '');

$dept = $auth->isSuperAdmin() ? null : $currentUser['department'];

// Get documents for user's department only (unless superadmin -> null = all)
$result = $document->getDocumentsByDepartment($dept, $page, $keyword);
$documents = $result['documents'];
$pagination = $result['pagination'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dokumen - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                min-height: 100vh;
                background: #f8f9fa;
            }
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 767.98px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                overflow: visible;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: 0;
                background: #f8f9fa;
            }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }
        .user-info {
            background: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
        }
        .document-card {
            border-left: 4px solid #495057;
            transition: all 0.3s ease;
            margin-bottom: 1rem;
        }
        .document-card:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        .category-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
        }
        .department-badge {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            color: white;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="user-info text-center">
                        <i class="fas fa-user-circle fa-3x mb-2"></i>
                        <h6><?php echo htmlspecialchars($currentUser['full_name']); ?></h6>
                        <small class="text-white-50">
                            <i class="fas fa-building me-1"></i>
                            <?php echo htmlspecialchars($currentUser['department']); ?>
                        </small>
                        <div class="mt-2">
                            <span class="badge bg-light text-dark">
                                <i class="fas fa-user-shield me-1"></i>
                                <?php echo ucfirst($currentUser['role']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link active" href="documents.php">
                            <i class="fas fa-file-alt me-2"></i>Dokumen
                        </a>
                        <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="upload.php">
                                <i class="fas fa-upload me-2"></i>Upload
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search me-2"></i>Pencarian
                        </a>
                        <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags me-2"></i>Kategori
                            </a>
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-line me-2"></i>Laporan
                            </a>
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-cog me-2"></i>Profile
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <span class="navbar-brand">
                                <i class="fas fa-file-alt me-2"></i>
                                Dokumen Department
                            </span>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-clock me-1"></i>
                                    <?php echo date('d/m/Y H:i'); ?>
                                </span>
                                <div class="dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                        <i class="fas fa-user-circle me-1"></i>
                                        <?php echo htmlspecialchars($currentUser['username']); ?>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="profile.php">
                                            <i class="fas fa-user me-2"></i>Profile
                                        </a></li>
                                        <li><hr class="dropdown-divider"></li>
                                        <li><a class="dropdown-item" href="logout.php">
                                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                                        </a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- Content -->
                    <div class="p-4">
                        <div class="row mb-4">
                            <div class="col-12">
                                <h2 class="mb-1">
                                    <i class="fas fa-file-alt me-2"></i>Dokumen Department
                                </h2>
                                <p class="text-muted">Dokumen yang ditujukan untuk department Anda</p>
                            </div>
                        </div>
                        
                        <!-- Filter Section -->
                        <div class="card mb-4">
                            <div class="card-body">
                                <form method="GET" action="" class="row g-3">
                                    <div class="col-md-4">
                                        <div class="alert alert-info mb-0">
                                            <i class="fas fa-info-circle me-2"></i>
                                            Menampilkan dokumen untuk: <strong><?php echo htmlspecialchars($currentUser['department']); ?></strong>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <label class="form-label">
                                            <i class="fas fa-search me-1"></i>Cari Dokumen
                                        </label>
                                        <input type="text" class="form-control" name="keyword" 
                                               value="<?php echo htmlspecialchars($keyword); ?>" 
                                               placeholder="Cari berdasarkan judul, deskripsi, atau tags...">
                                    </div>
                                    
                                    <div class="col-md-2 d-flex align-items-end">
                                        <button type="submit" class="btn btn-primary w-100">
                                            <i class="fas fa-search me-2"></i>Cari
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        <!-- Document List -->
                        <div class="row">
                            <div class="col-12">
                                <?php if (empty($documents)): ?>
                                    <div class="card">
                                        <div class="card-body text-center py-5">
                                            <i class="fas fa-folder-open fa-4x text-muted mb-3"></i>
                                            <h5>Tidak Ada Dokumen</h5>
                                            <p class="text-muted">
                                                <?php if (empty($keyword)): ?>
                                                    Belum ada dokumen untuk department ini.
                                                <?php else: ?>
                                                    Tidak ada dokumen yang sesuai dengan pencarian &quot;<?php echo htmlspecialchars($keyword); ?>&quot;.
                                                <?php endif; ?>
                                            </p>
                                            <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                                                <a href="upload.php" class="btn btn-primary">
                                                    <i class="fas fa-upload me-2"></i>Upload Dokumen
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="card">
                                        <div class="card-header bg-white">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <h6 class="mb-0">
                                                    <i class="fas fa-list me-2"></i>
                                                    Daftar Dokumen (<?php echo number_format($pagination['total_records']); ?>)
                                                </h6>
                                                <?php if (!empty($keyword)): ?>
                                                    <a href="documents.php" class="btn btn-sm btn-outline-secondary">
                                                        <i class="fas fa-times me-1"></i>Clear Filter
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <?php foreach ($documents as $doc): ?>
                                                <div class="document-card card">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-8">
                                                                <h5 class="card-title mb-2">
                                                                    <i class="fas fa-file-pdf text-danger me-2"></i>
                                                                    <?php echo htmlspecialchars($doc['title']); ?>
                                                                </h5>
                                                                <p class="card-text text-muted small mb-2">
                                                                    <?php echo htmlspecialchars($doc['description']); ?>
                                                                </p>
                                                                <div class="d-flex flex-wrap gap-2 align-items-center">
                                                                    <span class="category-badge" 
                                                                          style="background-color: <?php echo htmlspecialchars($doc['category_color']); ?>; color: white;">
                                                                        <i class="fas fa-tag me-1"></i>
                                                                        <?php echo htmlspecialchars($doc['category_name']); ?>
                                                                    </span>
                                                                    <span class="department-badge">
                                                                        <i class="fas fa-building me-1"></i>
                                                                        <?php echo htmlspecialchars($doc['target_department']); ?>
                                                                    </span>
                                                                    <?php if ($doc['shift']): ?>
                                                                        <small class="text-muted">
                                                                            <i class="fas fa-clock me-1"></i>
                                                                            Shift <?php echo ucfirst(htmlspecialchars($doc['shift'])); ?>
                                                                        </small>
                                                                    <?php endif; ?>
                                                                    <?php if ($doc['page_count']): ?>
                                                                        <small class="text-muted">
                                                                            <i class="fas fa-file me-1"></i>
                                                                            <?php echo htmlspecialchars($doc['page_count']); ?> hal
                                                                        </small>
                                                                    <?php endif; ?>
                                                                </div>
                                                            </div>
                                                            <div class="col-md-4 text-end">
                                                                <small class="text-muted d-block mb-2">
                                                                    <i class="fas fa-user me-1"></i>
                                                                    <?php echo htmlspecialchars($doc['uploader_name']); ?>
                                                                </small>
                                                                <small class="text-muted d-block mb-3">
                                                                    <i class="fas fa-calendar me-1"></i>
                                                                    <?php echo date('d/m/Y H:i', strtotime($doc['upload_date'])); ?>
                                                                </small>
                                                                <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                                                                    <a href="download.php?id=<?php echo $doc['id']; ?>" 
                                                                       class="btn btn-primary btn-sm">
                                                                        <i class="fas fa-download me-1"></i>Download
                                                                    </a>
                                                                <?php endif; ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                            
                                            <!-- Pagination -->
                                            <?php if ($pagination['total_pages'] > 1): ?>
                                                <nav aria-label="Document pagination" class="mt-4">
                                                    <ul class="pagination justify-content-center">
                                                        <?php if ($pagination['current_page'] > 1): ?>
                                                            <li class="page-item">
                                                                <a class="page-link" href="?keyword=<?php echo urlencode($keyword); ?>&page=<?php echo $pagination['current_page'] - 1; ?>">
                                                                    <i class="fas fa-chevron-left"></i>
                                                                </a>
                                                            </li>
                                                        <?php endif; ?>
                                                        
                                                        <?php for ($i = 1; $i <= $pagination['total_pages']; $i++): ?>
                                                            <li class="page-item <?php echo $i == $pagination['current_page'] ? 'active' : ''; ?>">
                                                                <a class="page-link" href="?keyword=<?php echo urlencode($keyword); ?>&page=<?php echo $i; ?>">
                                                                    <?php echo $i; ?>
                                                                </a>
                                                            </li>
                                                        <?php endfor; ?>
                                                        
                                                        <?php if ($pagination['current_page'] < $pagination['total_pages']): ?>
                                                            <li class="page-item">
                                                                <a class="page-link" href="?keyword=<?php echo urlencode($keyword); ?>&page=<?php echo $pagination['current_page'] + 1; ?>">
                                                                    <i class="fas fa-chevron-right"></i>
                                                                </a>
                                                            </li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </nav>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

