<?php
require_once 'config/config.php';
require_once 'classes/Auth.php';
require_once 'classes/Document.php';
require_once 'classes/Category.php';

// Check login
$auth = new Auth();
if (!$auth->isLoggedIn()) {
    redirect('login.php');
}

$currentUser = $auth->getCurrentUser();
$document = new Document();
$category = new Category();

// Get document ID
$documentId = (int)($_GET['id'] ?? 0);

if (!$documentId) {
    $_SESSION['error'] = 'ID dokumen tidak valid';
    redirect('search.php');
}

// Get document details
$doc = $document->getDocumentById($documentId);

if (!$doc) {
    $_SESSION['error'] = 'Dokumen tidak ditemukan';
    redirect('search.php');
}

// Check if user can edit this document
$canEdit = $auth->isAdmin() || $auth->isSuperAdmin() || $doc['uploaded_by'] == $currentUser['id'];

if (!$canEdit) {
    $_SESSION['error'] = 'Anda tidak memiliki izin untuk mengedit dokumen ini';
    redirect('search.php');
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize_input($_POST['title'] ?? '');
    $description = sanitize_input($_POST['description'] ?? '');
    $categoryId = (int)($_POST['category_id'] ?? 0);
    $shift = sanitize_input($_POST['shift'] ?? '');
    $pageCount = sanitize_input($_POST['page_count'] ?? '');
    $productionDate = sanitize_input($_POST['production_date'] ?? '');
    // Tags input removed from the form UI. Preserve existing tags when updating.
    $tags = $doc['tags'];
    
    // Validation
    $errors = [];
    
    if (empty($title)) {
        $errors[] = 'Judul dokumen harus diisi';
    }
    
    if (empty($description)) {
        $errors[] = 'Deskripsi dokumen harus diisi';
    }
    
    if ($categoryId <= 0) {
        $errors[] = 'Kategori harus dipilih';
    }
    
    if (!empty($pageCount) && (!is_numeric($pageCount) || $pageCount < 1)) {
        $errors[] = 'Jumlah halaman harus berupa angka positif';
    }
    
    if (!empty($productionDate) && !strtotime($productionDate)) {
        $errors[] = 'Format tanggal produksi tidak valid';
    }
    
    if (empty($errors)) {
        // Update document
        $result = $document->updateDocument(
            $documentId,
            $title,
            $description,
            $categoryId,
            $shift,
            $pageCount,
            $productionDate,
            $tags,
            $currentUser['id']
        );
        
        if ($result['success']) {
            $_SESSION['success'] = $result['message'];
            redirect('view_document.php?id=' . $documentId);
        } else {
            $errors[] = $result['message'];
        }
    }
}

// Get categories for dropdown
$categories = $category->getCategoriesForDropdown();

// Set form values (use POST data if available, otherwise use document data)
$formData = [
    'title' => $_POST['title'] ?? $doc['title'],
    'description' => $_POST['description'] ?? $doc['description'],
    'category_id' => $_POST['category_id'] ?? $doc['category_id'],
    'shift' => $_POST['shift'] ?? $doc['shift'],
    'page_count' => $_POST['page_count'] ?? $doc['page_count'],
    'production_date' => $_POST['production_date'] ?? $doc['production_date']
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Dokumen - <?php echo htmlspecialchars($doc['title']); ?> - <?php echo APP_NAME; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
         :root { --sidebar-width: 220px; }
        @media (min-width: 992px) { :root { --sidebar-width: 260px; } }

        @media (min-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                bottom: 0;
                width: var(--sidebar-width);
                overflow-y: auto;
                z-index: 1030;
                padding-top: 1rem;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: var(--sidebar-width);
                min-height: 100vh;
                background: #f8f9fa;
            }
            .col-md-3.col-lg-2.px-0,
            .col-md-3.col-lg-2.px-0.fixed {
                flex: 0 0 var(--sidebar-width) !important;
                max-width: var(--sidebar-width) !important;
                width: var(--sidebar-width) !important;
                padding: 0 !important;
                margin: 0 !important;
            }
        }

        @media (max-width: 767.98px) {
            .sidebar {
                position: static;
                width: 100%;
                height: auto;
                overflow: visible;
                background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
                color: white;
            }

            .main-content {
                margin-left: 0;
                background: #f8f9fa;
            }
        }

        .sidebar .nav-link {
            color: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 2px 0;
            transition: all 0.3s ease;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: white;
            background: rgba(255, 255, 255, 0.1);
            transform: translateX(5px);
        }
        /* Reset dan pencegahan celah horizontal */
        html, body {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }
        @media (min-width: 768px) {
            .main-content { width: calc(100vw - var(--sidebar-width)); box-sizing: border-box; }
        }
        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
        }
        .form-control, .form-select {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
        }
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
            border-radius: 10px;
        }
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            border: none;
            border-radius: 10px;
        }
        .edit-form {
            background: white;
            border-radius: 15px;
            padding: 2rem;
        }
        .file-info {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 1rem;
            border-left: 4px solid #667eea;
        }
        .alert {
            border-radius: 10px;
            border: none;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 px-0">
                <div class="sidebar p-3">
                    <div class="text-center mb-4">
                        <i class="fas fa-file-alt fa-2x mb-2"></i>
                        <h6><?php echo APP_NAME; ?></h6>
                    </div>
                    
                    <nav class="nav flex-column">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a class="nav-link" href="documents.php">
                            <i class="fas fa-file-alt me-2"></i>Dokumen
                        </a>
                        <?php if (!$auth->isAdmin() && !$auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="upload.php">
                                <i class="fas fa-upload me-2"></i>Upload
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="search.php">
                            <i class="fas fa-search me-2"></i>Pencarian
                        </a>
                        <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                            <a class="nav-link" href="categories.php">
                                <i class="fas fa-tags me-2"></i>Kategori
                            </a>
                            <a class="nav-link" href="users.php">
                                <i class="fas fa-users me-2"></i>Users
                            </a>
                            <a class="nav-link" href="reports.php">
                                <i class="fas fa-chart-line me-2"></i>Laporan
                            </a>
                            <a class="nav-link" href="backup.php">
                                <i class="fas fa-database me-2"></i>Backup
                            </a>
                        <?php endif; ?>
                        <a class="nav-link" href="profile.php">
                            <i class="fas fa-user-cog me-2"></i>Profile
                        </a>
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 px-0">
                <div class="main-content">
                    <!-- Top Navbar -->
                    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
                        <div class="container-fluid">
                            <div class="d-flex align-items-center">
                                <a href="view_document.php?id=<?php echo $doc['id']; ?>" class="btn btn-outline-secondary btn-sm me-3">
                                    <i class="fas fa-arrow-left me-1"></i>Kembali
                                </a>
                                <span class="navbar-brand mb-0">
                                    <i class="fas fa-edit me-2"></i>Edit Dokumen
                                </span>
                            </div>
                            <div class="navbar-nav ms-auto">
                                <span class="navbar-text me-3">
                                    <i class="fas fa-user me-1"></i>
                                    <?php echo htmlspecialchars($currentUser['full_name']); ?>
                                </span>
                            </div>
                        </div>
                    </nav>
                    
                    <!-- Content -->
                    <div class="p-4">
                        <!-- Error Messages -->
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <i class="fas fa-exclamation-triangle me-2"></i>
                                <strong>Terjadi kesalahan:</strong>
                                <ul class="mb-0 mt-2">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo htmlspecialchars($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Success Messages -->
                        <?php if (isset($_SESSION['success'])): ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle me-2"></i>
                                <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="row">
                            <!-- Edit Form -->
                            <div class="col-lg-8">
                                <div class="edit-form">
                                    <h5 class="mb-4">
                                        <i class="fas fa-edit me-2"></i>Edit Informasi Dokumen
                                    </h5>
                                    
                                    <form method="POST" action="">
                                        <div class="row">
                                            <div class="col-md-12 mb-3">
                                                <label for="title" class="form-label">
                                                    <i class="fas fa-heading me-2"></i>Judul Dokumen *
                                                </label>
                                                <input type="text" class="form-control" id="title" name="title" 
                                                       value="<?php echo htmlspecialchars($formData['title']); ?>" 
                                                       placeholder="Masukkan judul dokumen" required>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-12 mb-3">
                                                <label for="description" class="form-label">
                                                    <i class="fas fa-align-left me-2"></i>Deskripsi *
                                                </label>
                                                <textarea class="form-control" id="description" name="description" 
                                                          rows="4" placeholder="Masukkan deskripsi dokumen" required><?php echo htmlspecialchars($formData['description']); ?></textarea>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label for="category_id" class="form-label">
                                                    <i class="fas fa-tags me-2"></i>Kategori *
                                                </label>
                                                <select class="form-select" id="category_id" name="category_id" required>
                                                    <option value="">Pilih Kategori</option>
                                                    <?php foreach ($categories as $cat): ?>
                                                        <option value="<?php echo $cat['id']; ?>" 
                                                                <?php echo $formData['category_id'] == $cat['id'] ? 'selected' : ''; ?>>
                                                            <?php echo htmlspecialchars($cat['name']); ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="shift" class="form-label">
                                                    <i class="fas fa-clock me-2"></i>Shift
                                                </label>
                                                <select class="form-select" id="shift" name="shift">
                                                    <option value="">Pilih Shift</option>
                                                    <option value="pagi" <?php echo $formData['shift'] == 'pagi' ? 'selected' : ''; ?>>Shift Pagi</option>
                                                    <option value="malam" <?php echo $formData['shift'] == 'malam' ? 'selected' : ''; ?>>Shift Malam</option>
                                                </select>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label for="page_count" class="form-label">
                                                    <i class="fas fa-file-pdf me-2"></i>Jumlah Halaman PDF
                                                </label>
                                                <input type="number" class="form-control" id="page_count" name="page_count" 
                                                       value="<?php echo htmlspecialchars($formData['page_count']); ?>" 
                                                       placeholder="Jumlah halaman" min="1">
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="production_date" class="form-label">
                                                    <i class="fas fa-calendar me-2"></i>Tanggal Produksi
                                                </label>
                                                <input type="date" class="form-control" id="production_date" name="production_date" 
                                                       value="<?php echo htmlspecialchars($formData['production_date']); ?>">
                                            </div>
                                        </div>
                                        
                                        <!-- Tags input removed per UI update; existing tags are preserved on save -->
                                        
                                        <div class="d-flex justify-content-between">
                                            <a href="view_document.php?id=<?php echo $doc['id']; ?>" class="btn btn-secondary">
                                                <i class="fas fa-times me-2"></i>Batal
                                            </a>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="fas fa-save me-2"></i>Simpan Perubahan
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            
                            <!-- Document Info -->
                            <div class="col-lg-4">
                                <div class="card">
                                    <div class="card-header">
                                        <h6 class="mb-0">
                                            <i class="fas fa-info-circle me-2"></i>Informasi File
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="file-info">
                                            <div class="mb-3">
                                                <small class="text-muted d-block">Nama File</small>
                                                <span class="fw-bold"><?php echo htmlspecialchars($doc['original_filename']); ?></span>
                                            </div>
                                            <div class="mb-3">
                                                <small class="text-muted d-block">Ukuran File</small>
                                                <span class="badge bg-info">
                                                    <?php echo format_file_size($doc['file_size']); ?>
                                                </span>
                                            </div>
                                            <div class="mb-3">
                                                <small class="text-muted d-block">Tipe File</small>
                                                <span class="badge bg-warning text-dark">
                                                    <?php echo strtoupper($doc['file_type']); ?>
                                                </span>
                                            </div>
                                            <div class="mb-3">
                                                <small class="text-muted d-block">Diupload Oleh</small>
                                                <span class="fw-bold"><?php echo htmlspecialchars($doc['uploader_name']); ?></span>
                                            </div>
                                            <div class="mb-0">
                                                <small class="text-muted d-block">Tanggal Upload</small>
                                                <span class="text-muted">
                                                    <?php echo date('d/m/Y H:i', strtotime($doc['upload_date'])); ?>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="mt-3">
                                            <small class="text-muted">
                                                <i class="fas fa-info-circle me-1"></i>
                                                File tidak dapat diubah. Hanya informasi dokumen yang dapat diedit.
                                            </small>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Quick Actions -->
                                <div class="card mt-3">
                                    <div class="card-header">
                                        <h6 class="mb-0">
                                            <i class="fas fa-bolt me-2"></i>Aksi Cepat
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-grid gap-2">
                                            <a href="view_document.php?id=<?php echo $doc['id']; ?>" class="btn btn-outline-primary btn-sm">
                                                <i class="fas fa-eye me-2"></i>Lihat Dokumen
                                            </a>
                                            <?php if ($auth->isAdmin() || $auth->isSuperAdmin()): ?>
                                                <a href="download.php?id=<?php echo $doc['id']; ?>" class="btn btn-outline-success btn-sm">
                                                    <i class="fas fa-download me-2"></i>Download
                                                </a>
                                            <?php endif; ?>
                                            <a href="search.php" class="btn btn-outline-secondary btn-sm">
                                                <i class="fas fa-search me-2"></i>Kembali ke Pencarian
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.querySelector('form');
            const titleInput = document.getElementById('title');
            const descriptionInput = document.getElementById('description');
            const categorySelect = document.getElementById('category_id');
            
            form.addEventListener('submit', function(e) {
                let isValid = true;
                
                // Clear previous error states
                [titleInput, descriptionInput, categorySelect].forEach(input => {
                    input.classList.remove('is-invalid');
                });
                
                // Validate title
                if (titleInput.value.trim() === '') {
                    titleInput.classList.add('is-invalid');
                    isValid = false;
                }
                
                // Validate description
                if (descriptionInput.value.trim() === '') {
                    descriptionInput.classList.add('is-invalid');
                    isValid = false;
                }
                
                // Validate category
                if (categorySelect.value === '') {
                    categorySelect.classList.add('is-invalid');
                    isValid = false;
                }
                
                if (!isValid) {
                    e.preventDefault();
                    alert('Mohon lengkapi semua field yang wajib diisi.');
                }
            });
            
            // Real-time validation
            [titleInput, descriptionInput, categorySelect].forEach(input => {
                input.addEventListener('input', function() {
                    if (this.classList.contains('is-invalid') && this.value.trim() !== '') {
                        this.classList.remove('is-invalid');
                    }
                });
            });
        });
    </script>
</body>
</html>
